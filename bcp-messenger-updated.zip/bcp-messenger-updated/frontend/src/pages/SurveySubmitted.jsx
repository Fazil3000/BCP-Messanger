import React from 'react';
import { useLocation, Link } from 'react-router-dom';

export default function SurveySubmitted() {
  const location = useLocation();
  const { incidentType, title } = location.state || { incidentType: 'Emergency Alert', title: 'BCP Campaign' };

  return (
    <div className="container" style={{ maxWidth: '650px', padding: '60px 20px', textAlign: 'center' }}>
      <div className="card" style={{ padding: '40px 30px' }}>
        <div style={{
          width: '72px',
          height: '72px',
          borderRadius: '50%',
          backgroundColor: 'var(--success-light)',
          color: 'var(--success)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '2.5rem',
          marginBottom: '20px'
        }}>
          ✓
        </div>

        <h1 style={{ fontSize: '1.75rem', marginBottom: '8px' }}>Response Recorded</h1>
        <p className="subtitle" style={{ fontSize: '1.05rem', color: '#334155' }}>
          Thank you for confirming your status for <strong>{title}</strong>.
        </p>

        <div style={{
          margin: '24px 0',
          padding: '16px',
          background: '#f8fafc',
          borderRadius: '8px',
          textAlign: 'left',
          fontSize: '0.9rem',
          color: '#475569',
          border: '1px solid var(--border)'
        }}>
          <div style={{ fontWeight: '700', color: '#0f172a', marginBottom: '6px' }}>
            ℹ️ Emergency Contacts & Help Desk:
          </div>
          <div>• BCP Emergency Hotline: <strong>1800-200-300</strong></div>
          <div>• Operations Response Center: <strong>bcp-ops@company.com</strong></div>
          <div>• Medical / Evacuation Support: <strong>Dial Local Emergency 100 / 108</strong></div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
          <Link to="/" className="btn btn-primary">
            Return to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
