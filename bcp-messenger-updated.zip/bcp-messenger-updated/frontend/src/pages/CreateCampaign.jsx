import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const INCIDENT_TYPES = [
  { value: 'FLOOD', label: '🌊 Flood Emergency' },
  { value: 'INTERNET_OUTAGE', label: '🌐 Internet Outage' },
  { value: 'POWER_OUTAGE', label: '⚡ Power Outage' },
  { value: 'CYCLONE', label: '🌀 Cyclone / Hurricane' },
  { value: 'FIRE_EMERGENCY', label: '🔥 Fire Emergency' },
  { value: 'OTHER', label: '⚠️ Other Incident' }
];

export default function CreateCampaign() {
  const [incidentType, setIncidentType] = useState('FLOOD');
  const [title, setTitle] = useState('Heavy Flooding in Chennai');
  const [message, setMessage] = useState('Due to heavy flooding and continuous rain, employees in affected zones are requested to immediately confirm their safety and indicate any assistance required.');
  const [questions, setQuestions] = useState([]);
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const navigate = useNavigate();

  // Fetch pre-stored questions dynamically from MySQL backend whenever incident type changes
  useEffect(() => {
    fetchQuestionsForIncident(incidentType);
  }, [incidentType]);

  const fetchQuestionsForIncident = async (type) => {
    try {
      setLoadingQuestions(true);
      const res = await api.get(`/api/bcp/questions/${type}`);
      setQuestions(res.data);
    } catch (err) {
      console.error('Failed to load questions from database', err);
    } finally {
      setLoadingQuestions(false);
    }
  };

  const handleIncidentChange = (e) => {
    const selected = e.target.value;
    setIncidentType(selected);

    // Default suggested titles and messages for convenience
    if (selected === 'FLOOD') {
      setTitle('Heavy Flooding Alert');
      setMessage('Due to heavy flooding, employees in affected areas are requested to confirm their safety.');
    } else if (selected === 'INTERNET_OUTAGE') {
      setTitle('Major Regional ISP Outage');
      setMessage('A widespread network outage has been reported in our main operations region. Please confirm your connectivity status.');
    } else if (selected === 'POWER_OUTAGE') {
      setTitle('Grid Power Failure Alert');
      setMessage('A major power grid outage is impacting the city. Please confirm if you have backup power or need to relocate.');
    } else if (selected === 'CYCLONE') {
      setTitle('Severe Cyclone Warning');
      setMessage('A severe cyclone is approaching coastal areas. Stay indoors and confirm your and your family’s safety.');
    } else if (selected === 'FIRE_EMERGENCY') {
      setTitle('Building Fire Incident & Evacuation');
      setMessage('An emergency evacuation was initiated at headquarters. Confirm that you have evacuated safely.');
    } else {
      setTitle('BCP Emergency Notification');
      setMessage('An unexpected business disruption has occurred. Please confirm your current safety status.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      const payload = {
        title,
        message,
        incidentType
      };

      const res = await api.post('/api/bcp/campaigns', payload);
      navigate('/campaigns');
    } catch (err) {
      console.error('Failed to create campaign', err);
      setError(err.response?.data?.message || 'Failed to create BCP Campaign. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container" style={{ maxWidth: '900px' }}>
      <div style={{ marginBottom: '24px' }}>
        <h1>Create BCP Campaign</h1>
        <p className="subtitle">Initiate a Business Continuity Plan alert with pre-stored survey questions.</p>
      </div>

      {error && (
        <div className="alert-box alert-danger">
          ⚠️ {error}
        </div>
      )}

      <div className="card">
        <form onSubmit={handleSubmit}>
          {/* Incident Type */}
          <div className="form-group">
            <label className="form-label">Select Incident Type *</label>
            <select
              className="form-select"
              value={incidentType}
              onChange={handleIncidentChange}
            >
              {INCIDENT_TYPES.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
            <span style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '4px', display: 'block' }}>
              Selecting an incident automatically loads official pre-stored survey questions from MySQL.
            </span>
          </div>

          {/* Title */}
          <div className="form-group">
            <label className="form-label">Alert Title *</label>
            <input
              type="text"
              required
              className="form-control"
              placeholder="e.g. Heavy Flooding in Chennai"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* Message */}
          <div className="form-group">
            <label className="form-label">Incident Instructions & Message *</label>
            <textarea
              required
              rows={4}
              className="form-textarea"
              placeholder="Describe the situation and actions employees should take..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
          </div>

          {/* Pre-stored Survey Questions Dynamic Preview */}
          <div style={{
            background: '#f8fafc',
            border: '1px solid var(--border)',
            borderRadius: '8px',
            padding: '20px',
            marginBottom: '24px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <div>
                <h4 style={{ fontSize: '1rem', color: '#0f172a' }}>
                  📋 Pre-stored Survey Questions ({incidentType.replace('_', ' ')})
                </h4>
                <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                  Loaded from MySQL database table `survey_questions`
                </div>
              </div>
              <span className="badge badge-approved">YES / NO Format</span>
            </div>

            {loadingQuestions ? (
              <div style={{ fontSize: '0.875rem', color: '#64748b' }}>Loading questions from database...</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {questions.map((q, idx) => (
                  <div
                    key={q.id || idx}
                    style={{
                      background: '#ffffff',
                      border: '1px solid #e2e8f0',
                      borderRadius: '6px',
                      padding: '10px 14px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{
                        width: '24px',
                        height: '24px',
                        borderRadius: '50%',
                        background: '#eff6ff',
                        color: '#2563eb',
                        fontWeight: '700',
                        fontSize: '0.8rem',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                      }}>
                        {idx + 1}
                      </span>
                      <span style={{ fontSize: '0.9rem', fontWeight: '500', color: '#1e293b' }}>
                        {q.questionText}
                      </span>
                    </div>
                    {q.assistanceTrigger && (
                      <span style={{ fontSize: '0.75rem', color: '#dc2626', fontWeight: '600' }}>
                        🚨 Triggers Assistance Flag
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
            <button
              type="button"
              onClick={() => navigate('/campaigns')}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="btn btn-primary"
            >
              {submitting ? 'Creating Alert...' : '🚀 Send BCP Alert for Approval'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
