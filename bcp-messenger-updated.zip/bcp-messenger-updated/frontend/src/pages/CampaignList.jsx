import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function CampaignList() {
  const { user, isApprover } = useAuth();
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);
  const [message, setMessage] = useState('');
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    try {
      setLoading(true);
      const res = await api.get('/api/bcp/campaigns');
      setCampaigns(res.data);
    } catch (err) {
      console.error('Failed to load campaigns', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (id) => {
    try {
      setActionLoading(id);
      setMessage('');
      const res = await api.put(`/api/bcp/campaigns/${id}/approve`);
      setMessage(`Campaign "${res.data.title}" approved and broadcast via Apache Kafka!`);
      fetchCampaigns();
    } catch (err) {
      console.error('Approval failed', err);
      alert(err.response?.data?.message || 'Approval failed. Please try again.');
    } finally {
      setActionLoading(null);
    }
  };

  const filteredCampaigns = campaigns.filter((c) => {
    if (filter === 'ALL') return true;
    return c.status === filter;
  });

  return (
    <div className="container">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h1>BCP Emergency Campaigns</h1>
          <p className="subtitle">Track incident lifecycle, approve emergency alerts, and view survey dispatches.</p>
        </div>
        {(user?.role === 'ADMIN' || user?.role === 'APPROVER') && (
          <Link to="/create-campaign" className="btn btn-primary">
            + Create New Alert
          </Link>
        )}
      </div>

      {message && (
        <div className="alert-box alert-success">
          ✅ {message}
        </div>
      )}

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '18px' }}>
        {['ALL', 'PENDING_APPROVAL', 'SENT', 'CLOSED'].map((tab) => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            className={`btn btn-sm ${filter === tab ? 'btn-primary' : 'btn-secondary'}`}
          >
            {tab.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="card">
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#64748b' }}>Loading campaigns...</div>
        ) : filteredCampaigns.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '40px', color: '#64748b' }}>
            No campaigns found for status "{filter.replace('_', ' ')}".
          </div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title & Message</th>
                  <th>Incident Type</th>
                  <th>Status</th>
                  <th>Created By</th>
                  <th>Dispatched</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredCampaigns.map((c) => (
                  <tr key={c.id}>
                    <td style={{ color: '#64748b', fontWeight: '600' }}>#{c.id}</td>
                    <td style={{ maxWidth: '320px' }}>
                      <div style={{ fontWeight: '700', color: '#0f172a' }}>{c.title}</div>
                      <div style={{
                        fontSize: '0.8rem',
                        color: '#64748b',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        marginTop: '2px'
                      }}>
                        {c.message}
                      </div>
                    </td>
                    <td>
                      <span style={{ fontWeight: '600', color: '#334155' }}>
                        {c.incidentType.replace('_', ' ')}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${
                        c.status === 'SENT' ? 'badge-sent' :
                        c.status === 'PENDING_APPROVAL' ? 'badge-pending' :
                        c.status === 'APPROVED' ? 'badge-approved' : 'badge-draft'
                      }`}>
                        {c.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.85rem' }}>{c.createdBy}</td>
                    <td style={{ fontSize: '0.85rem', color: '#64748b' }}>
                      {c.sentAt ? new Date(c.sentAt).toLocaleString() : 'Not dispatched'}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                        {/* Approver Action */}
                        {c.status === 'PENDING_APPROVAL' && isApprover && (
                          <button
                            onClick={() => handleApprove(c.id)}
                            disabled={actionLoading === c.id}
                            className="btn btn-success btn-sm"
                            title="Approve and broadcast via Kafka"
                          >
                            {actionLoading === c.id ? 'Publishing...' : 'Approve & Send 📢'}
                          </button>
                        )}

                        {/* Survey link for employees */}
                        {c.status === 'SENT' && (
                          <Link
                            to={`/survey/${c.surveyToken}`}
                            target="_blank"
                            className="btn btn-secondary btn-sm"
                            title="Open employee survey form"
                          >
                            Take Survey ↗
                          </Link>
                        )}

                        {/* Analytics */}
                        <Link
                          to={`/analytics/${c.id}`}
                          className="btn btn-secondary btn-sm"
                          title="View live response analytics"
                        >
                          Analytics
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
