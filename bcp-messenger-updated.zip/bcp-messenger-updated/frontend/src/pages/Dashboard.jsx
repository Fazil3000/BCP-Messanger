import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();
  const [summary, setSummary] = useState({
    totalCampaigns: 0,
    activeCampaigns: 0,
    totalResponses: 0,
    assistanceRequiredCount: 0
  });
  const [recentCampaigns, setRecentCampaigns] = useState([]);
  const [notificationStats, setNotificationStats] = useState({ totalNotifications: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [summaryRes, campaignsRes, notifRes] = await Promise.allSettled([
        api.get('/api/bcp/dashboard/summary'),
        api.get('/api/bcp/campaigns'),
        api.get('/api/notifications/stats')
      ]);

      if (summaryRes.status === 'fulfilled') {
        setSummary(summaryRes.value.data);
      }
      if (campaignsRes.status === 'fulfilled') {
        setRecentCampaigns(campaignsRes.value.data.slice(0, 5));
      }
      if (notifRes.status === 'fulfilled') {
        setNotificationStats(notifRes.value.data);
      }
    } catch (err) {
      console.error('Error loading dashboard data', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h1>BCP Operations Dashboard</h1>
          <p className="subtitle">Welcome back, {user?.fullName}. Real-time business continuity overview.</p>
        </div>
        {(user?.role === 'ADMIN' || user?.role === 'APPROVER') && (
          <Link to="/create-campaign" className="btn btn-primary">
            + Create BCP Alert
          </Link>
        )}
      </div>

      {/* KPI Stats Grid */}
      <div className="grid-4" style={{ marginBottom: '24px' }}>
        <div className="card" style={{ borderLeft: '4px solid #2563eb' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Total Campaigns
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: '#0f172a', margin: '6px 0' }}>
            {summary.totalCampaigns}
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>All created BCP events</div>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #16a34a' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Active Campaigns
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: '#16a34a', margin: '6px 0' }}>
            {summary.activeCampaigns}
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Dispatched & receiving surveys</div>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #8b5cf6' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Survey Responses
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: '#8b5cf6', margin: '6px 0' }}>
            {summary.totalResponses}
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Employee check-ins received</div>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #dc2626' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Assistance Required
          </div>
          <div style={{ fontSize: '2.2rem', fontWeight: '800', color: summary.assistanceRequiredCount > 0 ? '#dc2626' : '#0f172a', margin: '6px 0' }}>
            {summary.assistanceRequiredCount}
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Employees needing urgent support</div>
        </div>
      </div>

      {/* Quick Flow Guide & Recent Campaigns */}
      <div className="grid-3" style={{ marginBottom: '24px' }}>
        <div className="card" style={{ gridColumn: 'span 2' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h2>Recent BCP Campaigns</h2>
            <Link to="/campaigns" style={{ fontSize: '0.875rem', fontWeight: '600' }}>View All →</Link>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>Loading campaigns...</div>
          ) : recentCampaigns.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
              No BCP campaigns created yet. Click "+ Create BCP Alert" to initiate one.
            </div>
          ) : (
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Title</th>
                    <th>Incident</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {recentCampaigns.map((c) => (
                    <tr key={c.id}>
                      <td style={{ fontWeight: '600' }}>{c.title}</td>
                      <td>
                        <span style={{ fontSize: '0.85rem', fontWeight: '600', color: '#334155' }}>
                          {c.incidentType.replace('_', ' ')}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${
                          c.status === 'SENT' ? 'badge-sent' :
                          c.status === 'PENDING_APPROVAL' ? 'badge-pending' :
                          c.status === 'APPROVED' ? 'badge-approved' : 'badge-draft'
                        }`}>
                          {c.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td style={{ fontSize: '0.85rem', color: '#64748b' }}>
                        {new Date(c.createdAt).toLocaleDateString()}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <Link to={`/analytics/${c.id}`} className="btn btn-secondary btn-sm">
                            Analytics
                          </Link>
                          {c.status === 'SENT' && (
                            <Link to={`/survey/${c.surveyToken}`} target="_blank" className="btn btn-primary btn-sm">
                              Survey ↗
                            </Link>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* System Health / Architecture status */}
        <div className="card">
          <h3 style={{ marginBottom: '14px' }}>System Topology</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#f8fafc', borderRadius: '6px' }}>
              <span style={{ fontSize: '0.875rem', fontWeight: '600' }}>API Gateway</span>
              <span className="badge badge-sent">Active :8080</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#f8fafc', borderRadius: '6px' }}>
              <span style={{ fontSize: '0.875rem', fontWeight: '600' }}>Eureka Discovery</span>
              <span className="badge badge-sent">Active :8761</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#f8fafc', borderRadius: '6px' }}>
              <span style={{ fontSize: '0.875rem', fontWeight: '600' }}>Apache Kafka</span>
              <span className="badge badge-sent">Topic: bcp.campaign.created</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: '#f8fafc', borderRadius: '6px' }}>
              <span style={{ fontSize: '0.875rem', fontWeight: '600' }}>Notifications Dispatched</span>
              <span className="badge badge-approved">{notificationStats.totalNotifications} logs</span>
            </div>
          </div>

          <div style={{ marginTop: '20px', padding: '12px', background: '#eff6ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
            <div style={{ fontSize: '0.825rem', fontWeight: '700', color: '#1e40af', marginBottom: '4px' }}>
              💡 Hackathon Demo Flow
            </div>
            <div style={{ fontSize: '0.8rem', color: '#1e3a8a', lineHeight: '1.4' }}>
              1. Admin creates alert → 2. Approver approves → 3. Kafka triggers email → 4. Employees take YES/NO survey → 5. Live stats update.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
