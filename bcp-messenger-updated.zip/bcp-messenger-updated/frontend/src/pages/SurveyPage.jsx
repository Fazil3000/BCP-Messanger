import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function SurveyPage() {
  const { surveyToken } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [survey, setSurvey] = useState(null);
  const [employeeEmail, setEmployeeEmail] = useState(user?.email || '');
  const [employeeName, setEmployeeName] = useState(user?.fullName || '');
  const [employeeId, setEmployeeId] = useState(user?.employeeId || '');
  const [answers, setAnswers] = useState({});
  const [comments, setComments] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchSurveyDetails();
  }, [surveyToken]);

  useEffect(() => {
    if (user) {
      if (!employeeEmail) setEmployeeEmail(user.email);
      if (!employeeName) setEmployeeName(user.fullName);
      if (!employeeId) setEmployeeId(user.employeeId);
    }
  }, [user]);

  const fetchSurveyDetails = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await api.get(`/api/bcp/surveys/${surveyToken}`);
      setSurvey(res.data);

      // Initialize default answers to empty
      const initialAnswers = {};
      res.data.questions.forEach((q) => {
        initialAnswers[q.id] = '';
      });
      setAnswers(initialAnswers);
    } catch (err) {
      console.error('Error loading survey', err);
      setError(err.response?.data?.message || 'Unable to load survey. Please verify the survey link.');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerSelect = (questionId, value) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Verify all questions have an answer
    const unanswered = survey.questions.filter((q) => !answers[q.id]);
    if (unanswered.length > 0) {
      setError('Please answer all YES / NO questions before submitting.');
      return;
    }

    setSubmitting(true);

    try {
      const answersPayload = Object.entries(answers).map(([qId, val]) => ({
        questionId: parseInt(qId, 10),
        answer: val
      }));

      const payload = {
        employeeEmail,
        employeeName,
        employeeId,
        comments,
        answers: answersPayload
      };

      await api.post(`/api/bcp/surveys/${surveyToken}/submit`, payload);
      navigate('/survey-submitted', { state: { incidentType: survey.incidentType, title: survey.title } });
    } catch (err) {
      console.error('Survey submission failed', err);
      setError(err.response?.data?.message || 'Submission failed. You may have already submitted a response.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ textAlign: 'center', padding: '60px 20px' }}>
        <h2>Loading BCP Emergency Survey...</h2>
      </div>
    );
  }

  if (error && !survey) {
    return (
      <div className="container" style={{ maxWidth: '600px', marginTop: '40px' }}>
        <div className="alert-box alert-danger">
          ⚠️ {error}
        </div>
      </div>
    );
  }

  return (
    <div className="container" style={{ maxWidth: '800px' }}>
      {/* Emergency Header Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
        color: '#ffffff',
        borderRadius: '12px',
        padding: '28px 24px',
        marginBottom: '24px',
        boxShadow: 'var(--shadow-lg)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
          <span className="badge badge-danger" style={{ fontSize: '0.8rem', padding: '4px 12px' }}>
            🚨 EMERGENCY BCP ALERT
          </span>
          <span className="badge badge-draft" style={{ color: '#ffffff', background: 'rgba(255,255,255,0.15)' }}>
            {survey?.incidentType?.replace('_', ' ')}
          </span>
        </div>
        <h1 style={{ color: '#ffffff', fontSize: '1.75rem', marginTop: '6px' }}>{survey?.title}</h1>
        <p style={{ color: '#cbd5e1', fontSize: '0.95rem', marginTop: '10px', lineHeight: '1.6' }}>
          {survey?.message}
        </p>
      </div>

      {error && (
        <div className="alert-box alert-danger">
          ⚠️ {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {/* Employee Info Card */}
        <div className="card" style={{ marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '16px', fontSize: '1.15rem' }}>1. Employee Information</h3>
          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input
                type="text"
                required
                className="form-control"
                placeholder="e.g. John Doe"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Company Email *</label>
              <input
                type="email"
                required
                className="form-control"
                placeholder="e.g. employee1@company.com"
                value={employeeEmail}
                onChange={(e) => setEmployeeEmail(e.target.value)}
              />
            </div>
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label className="form-label">Employee ID (Optional)</label>
            <input
              type="text"
              className="form-control"
              placeholder="e.g. EMP003"
              value={employeeId}
              onChange={(e) => setEmployeeId(e.target.value)}
            />
          </div>
        </div>

        {/* Safety Questions Card */}
        <div className="card" style={{ marginBottom: '20px' }}>
          <div style={{ marginBottom: '16px' }}>
            <h3 style={{ fontSize: '1.15rem' }}>2. Safety & Readiness Questionnaire</h3>
            <p className="subtitle">Please answer each YES / NO question accurately.</p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {survey?.questions.map((q, idx) => {
              const currentAnswer = answers[q.id];
              return (
                <div
                  key={q.id}
                  style={{
                    padding: '16px',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    background: currentAnswer ? '#f8fafc' : '#ffffff'
                  }}
                >
                  <div style={{ fontSize: '0.975rem', fontWeight: '600', color: '#1e293b', marginBottom: '12px' }}>
                    {idx + 1}. {q.questionText}
                  </div>

                  <div style={{ display: 'flex', gap: '12px' }}>
                    <button
                      type="button"
                      onClick={() => handleAnswerSelect(q.id, 'YES')}
                      style={{
                        flex: 1,
                        padding: '10px 16px',
                        borderRadius: '8px',
                        border: currentAnswer === 'YES' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                        backgroundColor: currentAnswer === 'YES' ? '#eff6ff' : '#ffffff',
                        color: currentAnswer === 'YES' ? '#1d4ed8' : '#475569',
                        fontWeight: '700',
                        fontSize: '0.95rem'
                      }}
                    >
                      {currentAnswer === 'YES' ? '✓ YES' : 'YES'}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleAnswerSelect(q.id, 'NO')}
                      style={{
                        flex: 1,
                        padding: '10px 16px',
                        borderRadius: '8px',
                        border: currentAnswer === 'NO' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                        backgroundColor: currentAnswer === 'NO' ? '#eff6ff' : '#ffffff',
                        color: currentAnswer === 'NO' ? '#1d4ed8' : '#475569',
                        fontWeight: '700',
                        fontSize: '0.95rem'
                      }}
                    >
                      {currentAnswer === 'NO' ? '✓ NO' : 'NO'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="form-group" style={{ marginTop: '20px', marginBottom: 0 }}>
            <label className="form-label">Additional Comments / Specific Needs (Optional)</label>
            <textarea
              rows={3}
              className="form-textarea"
              placeholder="Provide any additional emergency context, current location, or specific medical/transportation assistance needed..."
              value={comments}
              onChange={(e) => setComments(e.target.value)}
            />
          </div>
        </div>

        {/* Submit */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '40px' }}>
          <button
            type="submit"
            disabled={submitting}
            className="btn btn-primary"
            style={{ width: '100%', padding: '14px', fontSize: '1rem' }}
          >
            {submitting ? 'Submitting Safety Confirmation...' : 'Submit Emergency Response →'}
          </button>
        </div>
      </form>
    </div>
  );
}
