import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../services/api';

export default function Analytics() {
  const { id } = useParams();
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchAnalytics();
  }, [id]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      setError('');
      const res = await api.get(`/api/bcp/campaigns/${id}/analytics`);
      setAnalytics(res.data);
    } catch (err) {
      console.error('Error fetching analytics', err);
      setError(err.response?.data?.message || 'Failed to load campaign analytics.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container" style={{ textAlign: 'center', padding: '60px 20px' }}>
        <h2>Loading Analytics...</h2>
      </div>
    );
  }

  if (error || !analytics) {
    return (
      <div className="container" style={{ maxWidth: '600px', marginTop: '40px' }}>
        <div className="alert-box alert-danger">
          ⚠️ {error || 'Analytics not found'}
        </div>
        <Link to="/campaigns" className="btn btn-secondary">← Back to Campaigns</Link>
      </div>
    );
  }

  return (
    <div className="container">
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Link to="/campaigns" style={{ fontSize: '0.9rem', color: '#64748b', fontWeight: '600' }}>← Campaigns</Link>
            <span style={{ color: '#cbd5e1' }}>/</span>
            <span className="badge badge-approved">{analytics.incidentType.replace('_', ' ')}</span>
          </div>
          <h1 style={{ marginTop: '6px' }}>{analytics.title}</h1>
          <p className="subtitle">
            Dispatched on: {analytics.sentAt ? new Date(analytics.sentAt).toLocaleString() : 'Not yet dispatched'}
          </p>
        </div>
        <button onClick={fetchAnalytics} className="btn btn-secondary btn-sm">
          🔄 Refresh Analytics
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid-3" style={{ marginBottom: '24px' }}>
        <div className="card" style={{ borderLeft: '4px solid #2563eb' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Total Responses Received
          </div>
          <div style={{ fontSize: '2.4rem', fontWeight: '800', color: '#0f172a', margin: '6px 0' }}>
            {analytics.totalResponses}
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Submitted employee surveys</div>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #16a34a' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Safe / Operational Rate
          </div>
          <div style={{ fontSize: '2.4rem', fontWeight: '800', color: '#16a34a', margin: '6px 0' }}>
            {analytics.safePercentage}%
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Employees confirmed safe</div>
        </div>

        <div className="card" style={{ borderLeft: '4px solid #dc2626' }}>
          <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
            Urgent Assistance Required
          </div>
          <div style={{ fontSize: '2.4rem', fontWeight: '800', color: analytics.assistanceRequiredCount > 0 ? '#dc2626' : '#0f172a', margin: '6px 0' }}>
            {analytics.assistanceRequiredCount} <span style={{ fontSize: '1rem', color: '#dc2626' }}>({analytics.assistancePercentage}%)</span>
          </div>
          <div style={{ fontSize: '0.825rem', color: '#64748b' }}>Employees flagged for help</div>
        </div>
      </div>

      {/* Question-by-Question Breakdown */}
      <div className="card" style={{ marginBottom: '24px' }}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '16px' }}>📊 Question-by-Question Response Breakdown</h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {analytics.questionBreakdown.map((q, idx) => {
            const total = q.yesCount + q.noCount;
            const yesPct = total > 0 ? Math.round((q.yesCount / total) * 100) : 0;
            const noPct = total > 0 ? Math.round((q.noCount / total) * 100) : 0;

            return (
              <div key={q.questionId} style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', border: '1px solid var(--border)' }}>
                <div style={{ fontWeight: '600', color: '#1e293b', marginBottom: '10px', fontSize: '0.95rem' }}>
                  {idx + 1}. {q.questionText}
                </div>

                {/* Bar */}
                <div style={{ display: 'flex', height: '24px', borderRadius: '6px', overflow: 'hidden', backgroundColor: '#e2e8f0', marginBottom: '8px' }}>
                  <div style={{ width: `${yesPct}%`, backgroundColor: '#2563eb', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '0.75rem', fontWeight: '700' }}>
                    {yesPct > 10 ? `${yesPct}% YES` : ''}
                  </div>
                  <div style={{ width: `${noPct}%`, backgroundColor: '#94a3b8', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '0.75rem', fontWeight: '700' }}>
                    {noPct > 10 ? `${noPct}% NO` : ''}
                  </div>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.825rem', color: '#64748b' }}>
                  <span><strong>YES:</strong> {q.yesCount} ({yesPct}%)</span>
                  <span><strong>NO:</strong> {q.noCount} ({noPct}%)</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Individual Employee Responses Table */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2 style={{ fontSize: '1.25rem' }}>👥 Employee Response Submissions</h2>
          <span style={{ fontSize: '0.85rem', color: '#64748b' }}>Total: {analytics.responses.length}</span>
        </div>

        {analytics.responses.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
            No employee responses submitted yet for this campaign.
          </div>
        ) : (
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Status</th>
                  <th>Submitted At</th>
                  <th>Answers Summary</th>
                  <th>Comments</th>
                </tr>
              </thead>
              <tbody>
                {analytics.responses.map((r) => (
                  <tr key={r.responseId} style={{ backgroundColor: r.needsAssistance ? '#fff5f5' : 'inherit' }}>
                    <td>
                      <div style={{ fontWeight: '700', color: '#0f172a' }}>{r.employeeName}</div>
                      <div style={{ fontSize: '0.8rem', color: '#64748b' }}>{r.employeeEmail} {r.employeeId ? `(${r.employeeId})` : ''}</div>
                    </td>
                    <td>
                      {r.needsAssistance ? (
                        <span className="badge badge-danger">🚨 Needs Assistance</span>
                      ) : (
                        <span className="badge badge-sent">✓ Safe</span>
                      )}
                    </td>
                    <td style={{ fontSize: '0.85rem', color: '#64748b' }}>
                      {new Date(r.submittedAt).toLocaleString()}
                    </td>
                    <td style={{ maxWidth: '300px' }}>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                        {Object.entries(r.answers).map(([question, ans], i) => (
                          <span
                            key={i}
                            style={{
                              fontSize: '0.725rem',
                              padding: '2px 6px',
                              borderRadius: '4px',
                              background: ans === 'YES' ? '#dbeafe' : '#f1f5f9',
                              color: ans === 'YES' ? '#1e40af' : '#475569',
                              fontWeight: '600'
                            }}
                            title={question}
                          >
                            Q{i+1}: {ans}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td style={{ fontSize: '0.85rem', color: '#334155' }}>
                      {r.comments || '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
