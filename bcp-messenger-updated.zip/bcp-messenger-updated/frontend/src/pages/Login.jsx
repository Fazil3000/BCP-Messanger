import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleQuickLogin = (quickEmail, quickPassword) => {
    setEmail(quickEmail);
    setPassword(quickPassword);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      console.error('Login error', err);
      setError(err.response?.data?.message || 'Invalid email or password. Please verify credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{
      minHeight: 'calc(100vh - 70px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    }}>
      <div className="card" style={{ width: '100%', maxWidth: '440px', padding: '36px' }}>
        <div style={{ textAlign: 'center', marginBottom: '28px' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '56px',
            height: '56px',
            borderRadius: '14px',
            background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
            color: '#fff',
            fontSize: '1.75rem',
            marginBottom: '12px'
          }}>
            🛡️
          </div>
          <h2>BCP Messenger</h2>
          <p className="subtitle">Business Continuity & Crisis Response Portal</p>
        </div>

        {error && (
          <div className="alert-box alert-danger">
            ⚠️ {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Company Email</label>
            <input
              type="email"
              required
              className="form-control"
              placeholder="e.g. admin@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              required
              className="form-control"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="btn btn-primary"
            style={{ width: '100%', marginTop: '8px', padding: '12px' }}
          >
            {submitting ? 'Authenticating...' : 'Sign In to Portal'}
          </button>
        </form>

        <div style={{ marginTop: '28px', paddingTop: '20px', borderTop: '1px solid var(--border)' }}>
          <div style={{ fontSize: '0.78rem', fontWeight: '700', color: '#64748b', textTransform: 'uppercase', marginBottom: '10px', textAlign: 'center' }}>
            Demo Quick Login Presets
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <button
              type="button"
              onClick={() => handleQuickLogin('admin@company.com', 'Admin@123')}
              className="btn btn-secondary btn-sm"
              style={{ justifyContent: 'space-between' }}
            >
              <span>👑 <strong>Admin</strong> (admin@company.com)</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Fill</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('approver@company.com', 'Approver@123')}
              className="btn btn-secondary btn-sm"
              style={{ justifyContent: 'space-between' }}
            >
              <span>✍️ <strong>Approver</strong> (approver@company.com)</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Fill</span>
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('employee1@company.com', 'Employee@123')}
              className="btn btn-secondary btn-sm"
              style={{ justifyContent: 'space-between' }}
            >
              <span>👤 <strong>Employee</strong> (employee1@company.com)</span>
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Fill</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
