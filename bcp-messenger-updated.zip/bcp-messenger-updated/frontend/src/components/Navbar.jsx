import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav style={{
      backgroundColor: '#ffffff',
      borderBottom: '1px solid var(--border)',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }}>
      <div className="container" style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingTop: '14px',
        paddingBottom: '14px'
      }}>
        {/* Brand */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={{
            width: '38px',
            height: '38px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontWeight: 'bold',
            fontSize: '1.2rem'
          }}>
            🛡️
          </div>
          <div>
            <span style={{ fontSize: '1.15rem', fontWeight: '800', color: '#0f172a' }}>BCP</span>
            <span style={{ fontSize: '1.15rem', fontWeight: '700', color: '#2563eb' }}>Messenger</span>
          </div>
        </Link>

        {/* Links */}
        {isAuthenticated ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <Link to="/" style={{ fontWeight: '600', color: '#334155' }}>Dashboard</Link>
            <Link to="/campaigns" style={{ fontWeight: '600', color: '#334155' }}>Campaigns</Link>
            {(user?.role === 'ADMIN' || user?.role === 'APPROVER') && (
              <Link to="/create-campaign" className="btn btn-primary btn-sm">
                + New Alert
              </Link>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginLeft: '12px', borderLeft: '1px solid var(--border)', paddingLeft: '16px' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#0f172a' }}>{user?.fullName}</div>
                <span className={`badge ${user?.role === 'ADMIN' ? 'badge-danger' : user?.role === 'APPROVER' ? 'badge-approved' : 'badge-draft'}`}>
                  {user?.role}
                </span>
              </div>
              <button onClick={handleLogout} className="btn btn-secondary btn-sm" title="Sign out">
                Logout
              </button>
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', gap: '10px' }}>
            <Link to="/login" className="btn btn-primary btn-sm">
              Sign In
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
