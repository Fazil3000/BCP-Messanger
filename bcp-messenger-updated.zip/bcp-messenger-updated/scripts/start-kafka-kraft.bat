@echo off
echo ======================================================================
echo  BCP Messenger - Standalone Kafka KRaft Mode Startup (No Docker Needed)
echo ======================================================================
echo.
echo Make sure KAFKA_HOME is set or edit the KAFKA_DIR path below.
echo Example: C:\kafka_2.13-3.7.0

set KAFKA_DIR=C:\kafka
if not exist "%KAFKA_DIR%" (
    set /p KAFKA_DIR="Enter your Kafka installation directory (e.g., C:\kafka_2.13-3.7.0): "
)

if not exist "%KAFKA_DIR%\bin\windows\kafka-server-start.bat" (
    echo [ERROR] Kafka not found at %KAFKA_DIR%.
    echo Please download Apache Kafka binary from https://kafka.apache.org/downloads
    echo Extract to C:\kafka and run this script again.
    pause
    exit /b 1
)

echo [INFO] Generating KRaft Cluster ID...
for /f "tokens=*" %%i in ('"%KAFKA_DIR%\bin\windows\kafka-storage.bat" random-uuid') do set CLUSTER_ID=%%i
echo Cluster ID: %CLUSTER_ID%

echo [INFO] Formatting Kafka storage directory...
call "%KAFKA_DIR%\bin\windows\kafka-storage.bat" format -t %CLUSTER_ID% -c "%KAFKA_DIR%\config\kraft\server.properties"

echo [INFO] Starting Kafka Server in KRaft mode (Port 9092)...
call "%KAFKA_DIR%\bin\windows\kafka-server-start.bat" "%KAFKA_DIR%\config\kraft\server.properties"

pause
