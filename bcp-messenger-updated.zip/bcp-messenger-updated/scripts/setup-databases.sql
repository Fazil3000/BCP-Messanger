-- ==========================================================
-- BCP Messenger - MySQL Database Setup Script
-- Run this script in MySQL Workbench or MySQL CLI:
-- mysql -u root -p < setup-databases.sql
-- ==========================================================

-- 1. User Service Database
CREATE DATABASE IF NOT EXISTS bcp_user_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- 2. BCP Service Database (Campaigns, Questions, Responses)
CREATE DATABASE IF NOT EXISTS bcp_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- 3. Notification Service Database
CREATE DATABASE IF NOT EXISTS bcp_notification_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

-- Verification
SHOW DATABASES LIKE 'bcp%';
