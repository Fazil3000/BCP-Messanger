@echo off
echo ======================================================================
echo           BCP Messenger - Stopping All Microservices Ports
echo ======================================================================
echo.

set PORTS=8761 8888 8080 8081 8082 8083 5173

for %%P in (%PORTS%) do (
    echo Checking for process on port %%P...
    for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":%%P" ^| findstr "LISTENING"') do (
        echo Killing PID %%a on port %%P...
        taskkill /F /PID %%a >nul 2>&1
    )
)

echo.
echo All microservice ports (8761, 8888, 8080, 8081, 8082, 8083, 5173) cleared!
pause
