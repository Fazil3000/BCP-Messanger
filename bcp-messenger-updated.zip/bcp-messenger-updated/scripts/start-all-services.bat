@echo off
title BCP Messenger - Services Launcher
echo ======================================================================
echo           BCP Messenger - Starting All Microservices
echo ======================================================================
echo.

set ROOT_DIR=%~dp0..
set BACKEND_DIR=%ROOT_DIR%\backend
set FRONTEND_DIR=%ROOT_DIR%\frontend

echo [1/7] Starting Eureka Server (Port 8761)...
start "Eureka Server [8761]" cmd /k "cd /d %BACKEND_DIR%\eureka-server && mvn spring-boot:run"
echo Waiting 12 seconds for Eureka Server to initialize...
timeout /t 12 /nobreak >nul

echo [2/7] Starting Config Server (Port 8888)...
start "Config Server [8888]" cmd /k "cd /d %BACKEND_DIR%\config-server && mvn spring-boot:run"
echo Waiting 8 seconds for Config Server...
timeout /t 8 /nobreak >nul

echo [3/7] Starting User Service (Port 8081)...
start "User Service [8081]" cmd /k "cd /d %BACKEND_DIR%\user-service && mvn spring-boot:run"

echo [4/7] Starting BCP Service (Port 8082)...
start "BCP Service [8082]" cmd /k "cd /d %BACKEND_DIR%\bcp-service && mvn spring-boot:run"

echo [5/7] Starting Notification Service (Port 8083)...
start "Notification Service [8083]" cmd /k "cd /d %BACKEND_DIR%\notification-service && mvn spring-boot:run"

echo Waiting 10 seconds before starting API Gateway...
timeout /t 10 /nobreak >nul

echo [6/7] Starting API Gateway (Port 8080)...
start "API Gateway [8080]" cmd /k "cd /d %BACKEND_DIR%\api-gateway && mvn spring-boot:run"

echo [7/7] Starting React Frontend (Port 5173)...
start "React Frontend [5173]" cmd /k "cd /d %FRONTEND_DIR% && npm run dev"

echo.
echo ======================================================================
echo  All services launched in separate windows!
echo  Eureka Dashboard:  http://localhost:8761
echo  API Gateway:       http://localhost:8080
echo  React Frontend:    http://localhost:5173
echo ======================================================================
pause
