# BCP Messenger - Backend Services

Please refer to the root [README.md](../README.md) for full architecture diagrams, setup guides, and mentor review questions.

### Standalone Backend Services:
1. `eureka-server` (Port: 8761)
2. `config-server` (Port: 8888)
3. `api-gateway` (Port: 8080)
4. `user-service` (Port: 8081)
5. `bcp-service` (Port: 8082)
6. `notification-service` (Port: 8083)

Each service has its own independent `pom.xml` using the official `spring-boot-starter-parent` (version 3.4.2) and Spring Cloud `2024.0.0`.
