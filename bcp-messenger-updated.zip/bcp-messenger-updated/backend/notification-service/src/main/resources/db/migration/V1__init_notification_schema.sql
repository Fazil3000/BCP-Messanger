-- V1__init_notification_schema.sql
-- Notification history and logs table

CREATE TABLE IF NOT EXISTS notification_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    campaign_id BIGINT NOT NULL,
    recipient_email VARCHAR(100) NOT NULL,
    incident_type VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    survey_url VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL, -- 'SENT', 'FAILED', 'SIMULATED'
    error_message TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
