package com.bcp.notification.service;

import com.bcp.notification.dto.CampaignCreatedEvent;
import com.bcp.notification.dto.NotificationResponse;
import com.bcp.notification.dto.NotificationStatsResponse;
import com.bcp.notification.entity.NotificationLog;
import com.bcp.notification.entity.NotificationStatus;
import com.bcp.notification.repository.NotificationLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationServiceImpl implements NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationServiceImpl.class);

    private final NotificationLogRepository repository;
    private final EmailService emailService;
    private final List<String> defaultRecipients;

    public NotificationServiceImpl(
            NotificationLogRepository repository,
            EmailService emailService,
            @Value("${app.email.default-employee-recipients:skfazil221@gmail.com,neeha405021@gmail.com}") List<String> defaultRecipients) {
        this.repository = repository;
        this.emailService = emailService;
        this.defaultRecipients = defaultRecipients;
    }

    @Override
    @Transactional
    public void processCampaignEvent(CampaignCreatedEvent event) {
        log.info("Processing CampaignCreatedEvent for Campaign ID: {}, Title: '{}'", event.getCampaignId(), event.getTitle());

        for (String recipient : defaultRecipients) {
            NotificationStatus status;
            String errorMessage = null;

            try {
                emailService.sendBcpAlertEmail(
                        recipient,
                        event.getIncidentType(),
                        event.getTitle(),
                        event.getMessage(),
                        event.getSurveyUrl()
                );
                status = emailService.isEmailEnabled() ? NotificationStatus.SENT : NotificationStatus.SIMULATED;
            } catch (Exception e) {
                log.error("Failed to send notification to {}: {}", recipient, e.getMessage());
                status = NotificationStatus.FAILED;
                errorMessage = e.getMessage();
            }

            NotificationLog logEntry = new NotificationLog(
                    event.getCampaignId(),
                    recipient,
                    event.getIncidentType(),
                    event.getTitle(),
                    event.getSurveyUrl(),
                    status,
                    errorMessage
            );
            repository.save(logEntry);
        }

        log.info("Successfully dispatched notifications to {} employees for Campaign ID: {}",
                defaultRecipients.size(), event.getCampaignId());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponse> getAllNotifications() {
        return repository.findAllByOrderBySentAtDesc().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponse> getNotificationsByCampaignId(Long campaignId) {
        return repository.findByCampaignIdOrderBySentAtDesc(campaignId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public NotificationStatsResponse getNotificationStats() {
        long total = repository.count();
        long sent = repository.countByStatus(NotificationStatus.SENT);
        long simulated = repository.countByStatus(NotificationStatus.SIMULATED);
        long failed = repository.countByStatus(NotificationStatus.FAILED);

        return new NotificationStatsResponse(total, sent, simulated, failed);
    }

    private NotificationResponse mapToResponse(NotificationLog log) {
        return new NotificationResponse(
                log.getId(),
                log.getCampaignId(),
                log.getRecipientEmail(),
                log.getIncidentType(),
                log.getTitle(),
                log.getSurveyUrl(),
                log.getStatus(),
                log.getErrorMessage(),
                log.getSentAt()
        );
    }
}
