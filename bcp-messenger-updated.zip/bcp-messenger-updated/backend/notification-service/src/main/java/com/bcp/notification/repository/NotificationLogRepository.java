package com.bcp.notification.repository;

import com.bcp.notification.entity.NotificationLog;
import com.bcp.notification.entity.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationLogRepository extends JpaRepository<NotificationLog, Long> {

    List<NotificationLog> findByCampaignIdOrderBySentAtDesc(Long campaignId);

    List<NotificationLog> findAllByOrderBySentAtDesc();

    long countByStatus(NotificationStatus status);
}
