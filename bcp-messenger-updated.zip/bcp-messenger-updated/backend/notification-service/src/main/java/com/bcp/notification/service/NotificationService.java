package com.bcp.notification.service;

import com.bcp.notification.dto.CampaignCreatedEvent;
import com.bcp.notification.dto.NotificationResponse;
import com.bcp.notification.dto.NotificationStatsResponse;

import java.util.List;

public interface NotificationService {

    void processCampaignEvent(CampaignCreatedEvent event);

    List<NotificationResponse> getAllNotifications();

    List<NotificationResponse> getNotificationsByCampaignId(Long campaignId);

    NotificationStatsResponse getNotificationStats();
}
