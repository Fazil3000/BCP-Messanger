package com.bcp.notification.dto;

import com.bcp.notification.entity.NotificationStatus;
import java.time.LocalDateTime;

public class NotificationResponse {

    private Long id;
    private Long campaignId;
    private String recipientEmail;
    private String incidentType;
    private String title;
    private String surveyUrl;
    private NotificationStatus status;
    private String errorMessage;
    private LocalDateTime sentAt;

    public NotificationResponse() {
    }

    public NotificationResponse(Long id, Long campaignId, String recipientEmail, String incidentType, String title, String surveyUrl, NotificationStatus status, String errorMessage, LocalDateTime sentAt) {
        this.id = id;
        this.campaignId = campaignId;
        this.recipientEmail = recipientEmail;
        this.incidentType = incidentType;
        this.title = title;
        this.surveyUrl = surveyUrl;
        this.status = status;
        this.errorMessage = errorMessage;
        this.sentAt = sentAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(String incidentType) {
        this.incidentType = incidentType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSurveyUrl() {
        return surveyUrl;
    }

    public void setSurveyUrl(String surveyUrl) {
        this.surveyUrl = surveyUrl;
    }

    public NotificationStatus getStatus() {
        return status;
    }

    public void setStatus(NotificationStatus status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }
}
