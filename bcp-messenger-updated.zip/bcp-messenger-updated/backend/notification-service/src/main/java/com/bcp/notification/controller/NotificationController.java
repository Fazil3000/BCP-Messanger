package com.bcp.notification.controller;

import com.bcp.notification.dto.NotificationResponse;
import com.bcp.notification.dto.NotificationStatsResponse;
import com.bcp.notification.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public ResponseEntity<List<NotificationResponse>> getAllNotifications() {
        return ResponseEntity.ok(notificationService.getAllNotifications());
    }

    @GetMapping("/campaign/{campaignId}")
    public ResponseEntity<List<NotificationResponse>> getNotificationsByCampaignId(@PathVariable Long campaignId) {
        return ResponseEntity.ok(notificationService.getNotificationsByCampaignId(campaignId));
    }

    @GetMapping("/stats")
    public ResponseEntity<NotificationStatsResponse> getNotificationStats() {
        return ResponseEntity.ok(notificationService.getNotificationStats());
    }
}
