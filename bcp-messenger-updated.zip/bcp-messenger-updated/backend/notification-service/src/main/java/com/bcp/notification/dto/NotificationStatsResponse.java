package com.bcp.notification.dto;

public class NotificationStatsResponse {

    private long totalNotifications;
    private long sentCount;
    private long simulatedCount;
    private long failedCount;

    public NotificationStatsResponse() {
    }

    public NotificationStatsResponse(long totalNotifications, long sentCount, long simulatedCount, long failedCount) {
        this.totalNotifications = totalNotifications;
        this.sentCount = sentCount;
        this.simulatedCount = simulatedCount;
        this.failedCount = failedCount;
    }

    public long getTotalNotifications() {
        return totalNotifications;
    }

    public void setTotalNotifications(long totalNotifications) {
        this.totalNotifications = totalNotifications;
    }

    public long getSentCount() {
        return sentCount;
    }

    public void setSentCount(long sentCount) {
        this.sentCount = sentCount;
    }

    public long getSimulatedCount() {
        return simulatedCount;
    }

    public void setSimulatedCount(long simulatedCount) {
        this.simulatedCount = simulatedCount;
    }

    public long getFailedCount() {
        return failedCount;
    }

    public void setFailedCount(long failedCount) {
        this.failedCount = failedCount;
    }
}
