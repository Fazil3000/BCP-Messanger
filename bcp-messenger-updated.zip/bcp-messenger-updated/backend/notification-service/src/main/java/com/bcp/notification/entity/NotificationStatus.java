package com.bcp.notification.entity;

public enum NotificationStatus {
    SENT,
    FAILED,
    SIMULATED
}
