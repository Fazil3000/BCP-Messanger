package com.bcp.notification.kafka;

import com.bcp.notification.dto.CampaignCreatedEvent;
import com.bcp.notification.service.NotificationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class CampaignEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(CampaignEventConsumer.class);

    private final NotificationService notificationService;

    public CampaignEventConsumer(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @KafkaListener(
            topics = "${app.kafka.topic.campaign-created:bcp.campaign.created}",
            groupId = "${spring.kafka.consumer.group-id:bcp-notification-group}"
    )
    public void consumeCampaignCreatedEvent(CampaignCreatedEvent event) {
        log.info("Received CampaignCreatedEvent from Kafka: Campaign ID={}, Incident Type='{}', Title='{}'",
                event.getCampaignId(), event.getIncidentType(), event.getTitle());

        try {
            notificationService.processCampaignEvent(event);
        } catch (Exception e) {
            log.error("Error processing CampaignCreatedEvent for Campaign ID {}: {}",
                    event.getCampaignId(), e.getMessage(), e);
        }
    }
}
