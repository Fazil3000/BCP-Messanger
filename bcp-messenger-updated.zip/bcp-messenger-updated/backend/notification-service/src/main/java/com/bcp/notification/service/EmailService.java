package com.bcp.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;
    private final boolean emailEnabled;
    private final String fromEmail;

    public EmailService(
            JavaMailSender mailSender,
            @Value("${app.email.enabled:false}") boolean emailEnabled,
            @Value("${app.email.from:bcp-alerts@company.com}") String fromEmail) {
        this.mailSender = mailSender;
        this.emailEnabled = emailEnabled;
        this.fromEmail = fromEmail;
    }

    public boolean isEmailEnabled() {
        return emailEnabled;
    }

    public void sendBcpAlertEmail(String toEmail, String incidentType, String title, String message, String surveyUrl) {
        String subject = "BCP Alert - " + incidentType + ": " + title;
        String body = String.format(
                "=====================================================\n" +
                "                    BCP ALERT\n" +
                "=====================================================\n\n" +
                "Incident: %s\n" +
                "Title: %s\n\n" +
                "Message:\n%s\n\n" +
                "-----------------------------------------------------\n" +
                "ACTION REQUIRED: Please confirm your safety and assistance\n" +
                "requirements immediately by clicking the survey link below:\n\n" +
                "Complete the survey:\n%s\n\n" +
                "-----------------------------------------------------\n" +
                "This is an automated emergency notification from BCP Messenger.\n" +
                "=====================================================",
                incidentType, title, message, surveyUrl
        );

        if (emailEnabled) {
            log.info("Sending live SMTP email to: {}", toEmail);
            try {
                SimpleMailMessage mailMessage = new SimpleMailMessage();
                mailMessage.setFrom(fromEmail);
                mailMessage.setTo(toEmail);
                mailMessage.setSubject(subject);
                mailMessage.setText(body);
                mailSender.send(mailMessage);
                log.info("Email successfully sent to: {}", toEmail);
            } catch (Exception e) {
                log.error("Failed to send SMTP email to {}: {}", toEmail, e.getMessage());
                throw new RuntimeException("SMTP email dispatch failed: " + e.getMessage(), e);
            }
        } else {
            // Simulated local mode (Clean console logging)
            log.info("\n[SIMULATED EMAIL DISPATCH - LOCAL DEV MODE (app.email.enabled=false)]\n" +
                     "------------------------------------------------------------------\n" +
                     "To: {}\n" +
                     "From: {}\n" +
                     "Subject: {}\n\n" +
                     "{}\n" +
                     "------------------------------------------------------------------",
                    toEmail, fromEmail, subject, body);
        }
    }
}
