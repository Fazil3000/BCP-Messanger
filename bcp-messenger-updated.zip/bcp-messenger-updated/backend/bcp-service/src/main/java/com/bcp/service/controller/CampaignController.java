package com.bcp.service.controller;

import com.bcp.service.dto.CampaignAnalyticsResponse;
import com.bcp.service.dto.CampaignResponse;
import com.bcp.service.dto.CreateCampaignRequest;
import com.bcp.service.entity.CampaignStatus;
import com.bcp.service.service.CampaignService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bcp/campaigns")
public class CampaignController {

    private final CampaignService campaignService;

    public CampaignController(CampaignService campaignService) {
        this.campaignService = campaignService;
    }

    @PostMapping
    public ResponseEntity<CampaignResponse> createCampaign(
            @Valid @RequestBody CreateCampaignRequest request,
            @RequestHeader(value = "X-User-Email", defaultValue = "admin@company.com") String userEmail) {
        CampaignResponse response = campaignService.createCampaign(request, userEmail);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<CampaignResponse>> getAllCampaigns(
            @RequestParam(required = false) CampaignStatus status) {
        if (status != null) {
            return ResponseEntity.ok(campaignService.getCampaignsByStatus(status));
        }
        return ResponseEntity.ok(campaignService.getAllCampaigns());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CampaignResponse> getCampaignById(@PathVariable Long id) {
        return ResponseEntity.ok(campaignService.getCampaignById(id));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<CampaignResponse> approveCampaign(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Email", defaultValue = "approver@company.com") String approvedBy) {
        CampaignResponse response = campaignService.approveCampaign(id, approvedBy);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{id}/analytics")
    public ResponseEntity<CampaignAnalyticsResponse> getCampaignAnalytics(@PathVariable Long id) {
        return ResponseEntity.ok(campaignService.getCampaignAnalytics(id));
    }
}
