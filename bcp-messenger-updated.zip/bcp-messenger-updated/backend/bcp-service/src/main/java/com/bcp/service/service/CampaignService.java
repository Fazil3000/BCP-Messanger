package com.bcp.service.service;

import com.bcp.service.dto.CampaignAnalyticsResponse;
import com.bcp.service.dto.CampaignResponse;
import com.bcp.service.dto.CreateCampaignRequest;
import com.bcp.service.entity.CampaignStatus;

import java.util.List;

public interface CampaignService {

    CampaignResponse createCampaign(CreateCampaignRequest request, String createdBy);

    CampaignResponse approveCampaign(Long id, String approvedBy);

    CampaignResponse getCampaignById(Long id);

    List<CampaignResponse> getAllCampaigns();

    List<CampaignResponse> getCampaignsByStatus(CampaignStatus status);

    CampaignAnalyticsResponse getCampaignAnalytics(Long id);
}
