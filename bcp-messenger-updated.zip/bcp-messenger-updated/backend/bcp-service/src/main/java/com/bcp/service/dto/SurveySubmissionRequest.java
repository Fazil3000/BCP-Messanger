package com.bcp.service.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public class SurveySubmissionRequest {

    @NotBlank(message = "Employee email is required")
    @Email(message = "Invalid email format")
    private String employeeEmail;

    @NotBlank(message = "Employee name is required")
    private String employeeName;

    private String employeeId;

    private String comments;

    @NotEmpty(message = "Survey answers cannot be empty")
    @Valid
    private List<SurveyAnswerSubmission> answers;

    public SurveySubmissionRequest() {
    }

    public String getEmployeeEmail() {
        return employeeEmail;
    }

    public void setEmployeeEmail(String employeeEmail) {
        this.employeeEmail = employeeEmail;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<SurveyAnswerSubmission> getAnswers() {
        return answers;
    }

    public void setAnswers(List<SurveyAnswerSubmission> answers) {
        this.answers = answers;
    }
}
