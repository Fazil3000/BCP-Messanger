package com.bcp.service.repository;

import com.bcp.service.entity.Campaign;
import com.bcp.service.entity.CampaignStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CampaignRepository extends JpaRepository<Campaign, Long> {

    Optional<Campaign> findBySurveyToken(String surveyToken);

    List<Campaign> findByStatus(CampaignStatus status);

    List<Campaign> findAllByOrderByCreatedAtDesc();

    long countByStatus(CampaignStatus status);
}
