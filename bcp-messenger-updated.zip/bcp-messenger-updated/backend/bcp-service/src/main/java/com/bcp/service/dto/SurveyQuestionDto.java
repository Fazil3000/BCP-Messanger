package com.bcp.service.dto;

import com.bcp.service.entity.IncidentType;

public class SurveyQuestionDto {

    private Long id;
    private IncidentType incidentType;
    private String questionText;
    private int questionOrder;
    private boolean isAssistanceTrigger;
    private String expectedSafeAnswer;

    public SurveyQuestionDto() {
    }

    public SurveyQuestionDto(Long id, IncidentType incidentType, String questionText, int questionOrder, boolean isAssistanceTrigger, String expectedSafeAnswer) {
        this.id = id;
        this.incidentType = incidentType;
        this.questionText = questionText;
        this.questionOrder = questionOrder;
        this.isAssistanceTrigger = isAssistanceTrigger;
        this.expectedSafeAnswer = expectedSafeAnswer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public int getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(int questionOrder) {
        this.questionOrder = questionOrder;
    }

    public boolean isAssistanceTrigger() {
        return isAssistanceTrigger;
    }

    public void setAssistanceTrigger(boolean assistanceTrigger) {
        isAssistanceTrigger = assistanceTrigger;
    }

    public String getExpectedSafeAnswer() {
        return expectedSafeAnswer;
    }

    public void setExpectedSafeAnswer(String expectedSafeAnswer) {
        this.expectedSafeAnswer = expectedSafeAnswer;
    }
}
