package com.bcp.service.dto;

public class DashboardSummaryResponse {

    private long totalCampaigns;
    private long activeCampaigns;
    private long totalResponses;
    private long assistanceRequiredCount;

    public DashboardSummaryResponse() {
    }

    public DashboardSummaryResponse(long totalCampaigns, long activeCampaigns, long totalResponses, long assistanceRequiredCount) {
        this.totalCampaigns = totalCampaigns;
        this.activeCampaigns = activeCampaigns;
        this.totalResponses = totalResponses;
        this.assistanceRequiredCount = assistanceRequiredCount;
    }

    public long getTotalCampaigns() {
        return totalCampaigns;
    }

    public void setTotalCampaigns(long totalCampaigns) {
        this.totalCampaigns = totalCampaigns;
    }

    public long getActiveCampaigns() {
        return activeCampaigns;
    }

    public void setActiveCampaigns(long activeCampaigns) {
        this.activeCampaigns = activeCampaigns;
    }

    public long getTotalResponses() {
        return totalResponses;
    }

    public void setTotalResponses(long totalResponses) {
        this.totalResponses = totalResponses;
    }

    public long getAssistanceRequiredCount() {
        return assistanceRequiredCount;
    }

    public void setAssistanceRequiredCount(long assistanceRequiredCount) {
        this.assistanceRequiredCount = assistanceRequiredCount;
    }
}
