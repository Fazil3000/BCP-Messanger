package com.bcp.service.entity;

public enum CampaignStatus {
    DRAFT,
    PENDING_APPROVAL,
    APPROVED,
    SENT,
    CLOSED
}
