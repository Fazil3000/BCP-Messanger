package com.bcp.service.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

public class CampaignCreatedEvent implements Serializable {

    private Long campaignId;
    private String incidentType;
    private String title;
    private String message;
    private String surveyId;
    private String surveyUrl;
    private String createdBy;
    private LocalDateTime timestamp;

    public CampaignCreatedEvent() {
    }

    public CampaignCreatedEvent(Long campaignId, String incidentType, String title, String message, String surveyId, String surveyUrl, String createdBy, LocalDateTime timestamp) {
        this.campaignId = campaignId;
        this.incidentType = incidentType;
        this.title = title;
        this.message = message;
        this.surveyId = surveyId;
        this.surveyUrl = surveyUrl;
        this.createdBy = createdBy;
        this.timestamp = timestamp;
    }

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(String incidentType) {
        this.incidentType = incidentType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(String surveyId) {
        this.surveyId = surveyId;
    }

    public String getSurveyUrl() {
        return surveyUrl;
    }

    public void setSurveyUrl(String surveyUrl) {
        this.surveyUrl = surveyUrl;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
