package com.bcp.service.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "survey_questions")
public class SurveyQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "incident_type", nullable = false, length = 50)
    private IncidentType incidentType;

    @Column(name = "question_text", nullable = false, length = 255)
    private String questionText;

    @Column(name = "question_order", nullable = false)
    private int questionOrder;

    @Column(name = "is_assistance_trigger", nullable = false)
    private boolean isAssistanceTrigger = false;

    @Column(name = "expected_safe_answer", nullable = false, length = 10)
    private String expectedSafeAnswer = "YES";

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    public SurveyQuestion() {
    }

    public SurveyQuestion(IncidentType incidentType, String questionText, int questionOrder, boolean isAssistanceTrigger, String expectedSafeAnswer) {
        this.incidentType = incidentType;
        this.questionText = questionText;
        this.questionOrder = questionOrder;
        this.isAssistanceTrigger = isAssistanceTrigger;
        this.expectedSafeAnswer = expectedSafeAnswer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public int getQuestionOrder() {
        return questionOrder;
    }

    public void setQuestionOrder(int questionOrder) {
        this.questionOrder = questionOrder;
    }

    public boolean isAssistanceTrigger() {
        return isAssistanceTrigger;
    }

    public void setAssistanceTrigger(boolean assistanceTrigger) {
        isAssistanceTrigger = assistanceTrigger;
    }

    public String getExpectedSafeAnswer() {
        return expectedSafeAnswer;
    }

    public void setExpectedSafeAnswer(String expectedSafeAnswer) {
        this.expectedSafeAnswer = expectedSafeAnswer;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
