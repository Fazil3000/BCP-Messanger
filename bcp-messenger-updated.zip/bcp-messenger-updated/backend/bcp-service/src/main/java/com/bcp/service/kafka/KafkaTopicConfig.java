package com.bcp.service.kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaTopicConfig {

    @Value("${app.kafka.topic.campaign-created:bcp.campaign.created}")
    private String campaignCreatedTopic;

    @Bean
    public NewTopic campaignCreatedTopic() {
        return TopicBuilder.name(campaignCreatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
