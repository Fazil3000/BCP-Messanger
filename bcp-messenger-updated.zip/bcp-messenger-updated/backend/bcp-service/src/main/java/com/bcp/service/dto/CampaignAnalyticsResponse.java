package com.bcp.service.dto;

import com.bcp.service.entity.CampaignStatus;
import com.bcp.service.entity.IncidentType;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class CampaignAnalyticsResponse {

    private Long campaignId;
    private String title;
    private IncidentType incidentType;
    private CampaignStatus status;
    private LocalDateTime sentAt;
    private long totalResponses;
    private long assistanceRequiredCount;
    private double assistancePercentage;
    private double safePercentage;
    private List<QuestionStat> questionBreakdown;
    private List<EmployeeResponseDetail> responses;

    public static class QuestionStat {
        private Long questionId;
        private String questionText;
        private long yesCount;
        private long noCount;

        public QuestionStat() {
        }

        public QuestionStat(Long questionId, String questionText, long yesCount, long noCount) {
            this.questionId = questionId;
            this.questionText = questionText;
            this.yesCount = yesCount;
            this.noCount = noCount;
        }

        public Long getQuestionId() {
            return questionId;
        }

        public void setQuestionId(Long questionId) {
            this.questionId = questionId;
        }

        public String getQuestionText() {
            return questionText;
        }

        public void setQuestionText(String questionText) {
            this.questionText = questionText;
        }

        public long getYesCount() {
            return yesCount;
        }

        public void setYesCount(long yesCount) {
            this.yesCount = yesCount;
        }

        public long getNoCount() {
            return noCount;
        }

        public void setNoCount(long noCount) {
            this.noCount = noCount;
        }
    }

    public static class EmployeeResponseDetail {
        private Long responseId;
        private String employeeName;
        private String employeeEmail;
        private String employeeId;
        private boolean needsAssistance;
        private String comments;
        private LocalDateTime submittedAt;
        private Map<String, String> answers;

        public EmployeeResponseDetail() {
        }

        public EmployeeResponseDetail(Long responseId, String employeeName, String employeeEmail, String employeeId, boolean needsAssistance, String comments, LocalDateTime submittedAt, Map<String, String> answers) {
            this.responseId = responseId;
            this.employeeName = employeeName;
            this.employeeEmail = employeeEmail;
            this.employeeId = employeeId;
            this.needsAssistance = needsAssistance;
            this.comments = comments;
            this.submittedAt = submittedAt;
            this.answers = answers;
        }

        public Long getResponseId() {
            return responseId;
        }

        public void setResponseId(Long responseId) {
            this.responseId = responseId;
        }

        public String getEmployeeName() {
            return employeeName;
        }

        public void setEmployeeName(String employeeName) {
            this.employeeName = employeeName;
        }

        public String getEmployeeEmail() {
            return employeeEmail;
        }

        public void setEmployeeEmail(String employeeEmail) {
            this.employeeEmail = employeeEmail;
        }

        public String getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(String employeeId) {
            this.employeeId = employeeId;
        }

        public boolean isNeedsAssistance() {
            return needsAssistance;
        }

        public void setNeedsAssistance(boolean needsAssistance) {
            this.needsAssistance = needsAssistance;
        }

        public String getComments() {
            return comments;
        }

        public void setComments(String comments) {
            this.comments = comments;
        }

        public LocalDateTime getSubmittedAt() {
            return submittedAt;
        }

        public void setSubmittedAt(LocalDateTime submittedAt) {
            this.submittedAt = submittedAt;
        }

        public Map<String, String> getAnswers() {
            return answers;
        }

        public void setAnswers(Map<String, String> answers) {
            this.answers = answers;
        }
    }

    public CampaignAnalyticsResponse() {
    }

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }

    public CampaignStatus getStatus() {
        return status;
    }

    public void setStatus(CampaignStatus status) {
        this.status = status;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public long getTotalResponses() {
        return totalResponses;
    }

    public void setTotalResponses(long totalResponses) {
        this.totalResponses = totalResponses;
    }

    public long getAssistanceRequiredCount() {
        return assistanceRequiredCount;
    }

    public void setAssistanceRequiredCount(long assistanceRequiredCount) {
        this.assistanceRequiredCount = assistanceRequiredCount;
    }

    public double getAssistancePercentage() {
        return assistancePercentage;
    }

    public void setAssistancePercentage(double assistancePercentage) {
        this.assistancePercentage = assistancePercentage;
    }

    public double getSafePercentage() {
        return safePercentage;
    }

    public void setSafePercentage(double safePercentage) {
        this.safePercentage = safePercentage;
    }

    public List<QuestionStat> getQuestionBreakdown() {
        return questionBreakdown;
    }

    public void setQuestionBreakdown(List<QuestionStat> questionBreakdown) {
        this.questionBreakdown = questionBreakdown;
    }

    public List<EmployeeResponseDetail> getResponses() {
        return responses;
    }

    public void setResponses(List<EmployeeResponseDetail> responses) {
        this.responses = responses;
    }
}
