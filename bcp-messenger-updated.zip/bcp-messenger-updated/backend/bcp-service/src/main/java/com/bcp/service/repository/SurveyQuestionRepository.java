package com.bcp.service.repository;

import com.bcp.service.entity.IncidentType;
import com.bcp.service.entity.SurveyQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SurveyQuestionRepository extends JpaRepository<SurveyQuestion, Long> {

    List<SurveyQuestion> findByIncidentTypeOrderByQuestionOrderAsc(IncidentType incidentType);
}
