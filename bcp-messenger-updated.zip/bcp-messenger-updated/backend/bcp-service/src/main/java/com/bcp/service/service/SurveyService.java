package com.bcp.service.service;

import com.bcp.service.dto.SurveyDetailsResponse;
import com.bcp.service.dto.SurveyQuestionDto;
import com.bcp.service.dto.SurveySubmissionRequest;
import com.bcp.service.entity.IncidentType;

import java.util.List;

public interface SurveyService {

    List<SurveyQuestionDto> getQuestionsByIncidentType(IncidentType incidentType);

    SurveyDetailsResponse getSurveyDetailsByToken(String surveyToken);

    void submitSurvey(String surveyToken, SurveySubmissionRequest request);
}
