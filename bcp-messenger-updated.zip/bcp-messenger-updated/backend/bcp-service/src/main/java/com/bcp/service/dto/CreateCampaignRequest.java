package com.bcp.service.dto;

import com.bcp.service.entity.IncidentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CreateCampaignRequest {

    @NotBlank(message = "Campaign title is required")
    @Size(max = 150, message = "Title cannot exceed 150 characters")
    private String title;

    @NotBlank(message = "Campaign message is required")
    private String message;

    @NotNull(message = "Incident type is required")
    private IncidentType incidentType;

    public CreateCampaignRequest() {
    }

    public CreateCampaignRequest(String title, String message, IncidentType incidentType) {
        this.title = title;
        this.message = message;
        this.incidentType = incidentType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }
}
