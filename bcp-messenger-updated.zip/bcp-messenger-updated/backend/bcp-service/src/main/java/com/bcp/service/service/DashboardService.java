package com.bcp.service.service;

import com.bcp.service.dto.DashboardSummaryResponse;

public interface DashboardService {

    DashboardSummaryResponse getDashboardSummary();
}
