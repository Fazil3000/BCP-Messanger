package com.bcp.service.service;

import com.bcp.service.dto.*;
import com.bcp.service.entity.*;
import com.bcp.service.exception.InvalidOperationException;
import com.bcp.service.exception.ResourceNotFoundException;
import com.bcp.service.kafka.KafkaProducerService;
import com.bcp.service.repository.CampaignRepository;
import com.bcp.service.repository.SurveyAnswerRepository;
import com.bcp.service.repository.SurveyQuestionRepository;
import com.bcp.service.repository.SurveyResponseRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class CampaignServiceImpl implements CampaignService {

    private final CampaignRepository campaignRepository;
    private final SurveyQuestionRepository questionRepository;
    private final SurveyResponseRepository responseRepository;
    private final SurveyAnswerRepository answerRepository;
    private final KafkaProducerService kafkaProducerService;
    private final String frontendUrl;

    public CampaignServiceImpl(
            CampaignRepository campaignRepository,
            SurveyQuestionRepository questionRepository,
            SurveyResponseRepository responseRepository,
            SurveyAnswerRepository answerRepository,
            KafkaProducerService kafkaProducerService,
            @Value("${app.frontend-url:http://localhost:5173}") String frontendUrl) {
        this.campaignRepository = campaignRepository;
        this.questionRepository = questionRepository;
        this.responseRepository = responseRepository;
        this.answerRepository = answerRepository;
        this.kafkaProducerService = kafkaProducerService;
        this.frontendUrl = frontendUrl;
    }

    @Override
    @Transactional
    public CampaignResponse createCampaign(CreateCampaignRequest request, String createdBy) {
        String surveyToken = UUID.randomUUID().toString();
        Campaign campaign = new Campaign(
                request.getTitle(),
                request.getMessage(),
                request.getIncidentType(),
                surveyToken,
                createdBy,
                CampaignStatus.PENDING_APPROVAL
        );

        Campaign saved = campaignRepository.save(campaign);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public CampaignResponse approveCampaign(Long id, String approvedBy) {
        Campaign campaign = campaignRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Campaign not found with id: " + id));

        if (campaign.getStatus() == CampaignStatus.SENT || campaign.getStatus() == CampaignStatus.CLOSED) {
            throw new InvalidOperationException("Campaign is already in status: " + campaign.getStatus());
        }

        LocalDateTime now = LocalDateTime.now();
        campaign.setStatus(CampaignStatus.SENT);
        campaign.setApprovedBy(approvedBy);
        campaign.setApprovedAt(now);
        campaign.setSentAt(now);

        Campaign updated = campaignRepository.save(campaign);

        String surveyUrl = frontendUrl + "/survey/" + updated.getSurveyToken();

        // Publish CampaignCreatedEvent to Apache Kafka
        CampaignCreatedEvent event = new CampaignCreatedEvent(
                updated.getId(),
                updated.getIncidentType().name(),
                updated.getTitle(),
                updated.getMessage(),
                updated.getSurveyToken(),
                surveyUrl,
                updated.getCreatedBy(),
                now
        );

        kafkaProducerService.publishCampaignCreatedEvent(event);

        return mapToResponse(updated);
    }

    @Override
    @Transactional(readOnly = true)
    public CampaignResponse getCampaignById(Long id) {
        Campaign campaign = campaignRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Campaign not found with id: " + id));
        return mapToResponse(campaign);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CampaignResponse> getAllCampaigns() {
        return campaignRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<CampaignResponse> getCampaignsByStatus(CampaignStatus status) {
        return campaignRepository.findByStatus(status).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CampaignAnalyticsResponse getCampaignAnalytics(Long id) {
        Campaign campaign = campaignRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Campaign not found with id: " + id));

        List<SurveyResponse> responses = responseRepository.findByCampaignId(id);
        List<SurveyQuestion> questions = questionRepository.findByIncidentTypeOrderByQuestionOrderAsc(campaign.getIncidentType());

        long totalResponses = responses.size();
        long assistanceCount = responses.stream().filter(SurveyResponse::isNeedsAssistance).count();

        double assistancePercentage = totalResponses > 0 ? ((double) assistanceCount / totalResponses) * 100 : 0.0;
        double safePercentage = totalResponses > 0 ? (((double) (totalResponses - assistanceCount)) / totalResponses) * 100 : 0.0;

        List<CampaignAnalyticsResponse.QuestionStat> questionBreakdown = new ArrayList<>();
        for (SurveyQuestion q : questions) {
            long yesCount = answerRepository.countByQuestionIdAndAnswer(q.getId(), "YES");
            long noCount = answerRepository.countByQuestionIdAndAnswer(q.getId(), "NO");
            questionBreakdown.add(new CampaignAnalyticsResponse.QuestionStat(q.getId(), q.getQuestionText(), yesCount, noCount));
        }

        List<CampaignAnalyticsResponse.EmployeeResponseDetail> responseDetails = responses.stream().map(r -> {
            Map<String, String> answersMap = new HashMap<>();
            for (SurveyAnswer a : r.getAnswers()) {
                answersMap.put(a.getQuestionText(), a.getAnswer());
            }
            return new CampaignAnalyticsResponse.EmployeeResponseDetail(
                    r.getId(),
                    r.getEmployeeName(),
                    r.getEmployeeEmail(),
                    r.getEmployeeId(),
                    r.isNeedsAssistance(),
                    r.getComments(),
                    r.getSubmittedAt(),
                    answersMap
            );
        }).collect(Collectors.toList());

        CampaignAnalyticsResponse analytics = new CampaignAnalyticsResponse();
        analytics.setCampaignId(campaign.getId());
        analytics.setTitle(campaign.getTitle());
        analytics.setIncidentType(campaign.getIncidentType());
        analytics.setStatus(campaign.getStatus());
        analytics.setSentAt(campaign.getSentAt());
        analytics.setTotalResponses(totalResponses);
        analytics.setAssistanceRequiredCount(assistanceCount);
        analytics.setAssistancePercentage(Math.round(assistancePercentage * 10.0) / 10.0);
        analytics.setSafePercentage(Math.round(safePercentage * 10.0) / 10.0);
        analytics.setQuestionBreakdown(questionBreakdown);
        analytics.setResponses(responseDetails);

        return analytics;
    }

    private CampaignResponse mapToResponse(Campaign campaign) {
        String surveyUrl = frontendUrl + "/survey/" + campaign.getSurveyToken();
        return new CampaignResponse(
                campaign.getId(),
                campaign.getTitle(),
                campaign.getMessage(),
                campaign.getIncidentType(),
                campaign.getStatus(),
                campaign.getSurveyToken(),
                surveyUrl,
                campaign.getCreatedBy(),
                campaign.getApprovedBy(),
                campaign.getCreatedAt(),
                campaign.getApprovedAt(),
                campaign.getSentAt(),
                campaign.getClosedAt()
        );
    }
}
