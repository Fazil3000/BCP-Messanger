package com.bcp.service.service;

import com.bcp.service.dto.SurveyAnswerSubmission;
import com.bcp.service.dto.SurveyDetailsResponse;
import com.bcp.service.dto.SurveyQuestionDto;
import com.bcp.service.dto.SurveySubmissionRequest;
import com.bcp.service.entity.*;
import com.bcp.service.exception.InvalidOperationException;
import com.bcp.service.exception.ResourceNotFoundException;
import com.bcp.service.repository.CampaignRepository;
import com.bcp.service.repository.SurveyQuestionRepository;
import com.bcp.service.repository.SurveyResponseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SurveyServiceImpl implements SurveyService {

    private final CampaignRepository campaignRepository;
    private final SurveyQuestionRepository questionRepository;
    private final SurveyResponseRepository responseRepository;

    public SurveyServiceImpl(
            CampaignRepository campaignRepository,
            SurveyQuestionRepository questionRepository,
            SurveyResponseRepository responseRepository) {
        this.campaignRepository = campaignRepository;
        this.questionRepository = questionRepository;
        this.responseRepository = responseRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<SurveyQuestionDto> getQuestionsByIncidentType(IncidentType incidentType) {
        return questionRepository.findByIncidentTypeOrderByQuestionOrderAsc(incidentType).stream()
                .map(this::mapQuestionToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public SurveyDetailsResponse getSurveyDetailsByToken(String surveyToken) {
        Campaign campaign = campaignRepository.findBySurveyToken(surveyToken)
                .orElseThrow(() -> new ResourceNotFoundException("Survey not found with token: " + surveyToken));

        List<SurveyQuestionDto> questions = getQuestionsByIncidentType(campaign.getIncidentType());

        return new SurveyDetailsResponse(
                campaign.getSurveyToken(),
                campaign.getId(),
                campaign.getTitle(),
                campaign.getMessage(),
                campaign.getIncidentType(),
                campaign.getStatus(),
                questions
        );
    }

    @Override
    @Transactional
    public void submitSurvey(String surveyToken, SurveySubmissionRequest request) {
        Campaign campaign = campaignRepository.findBySurveyToken(surveyToken)
                .orElseThrow(() -> new ResourceNotFoundException("Survey not found with token: " + surveyToken));

        if (campaign.getStatus() == CampaignStatus.CLOSED) {
            throw new InvalidOperationException("This BCP survey campaign is closed.");
        }

        // Prevent duplicate submission from the same employee email
        Optional<SurveyResponse> existing = responseRepository.findByCampaignIdAndEmployeeEmail(
                campaign.getId(), request.getEmployeeEmail()
        );
        if (existing.isPresent()) {
            throw new InvalidOperationException("You have already submitted a response for this BCP alert.");
        }

        boolean overallNeedsAssistance = false;
        SurveyResponse surveyResponse = new SurveyResponse(
                campaign,
                request.getEmployeeEmail(),
                request.getEmployeeName(),
                request.getEmployeeId(),
                false,
                request.getComments()
        );

        for (SurveyAnswerSubmission answerSubmission : request.getAnswers()) {
            SurveyQuestion question = questionRepository.findById(answerSubmission.getQuestionId())
                    .orElseThrow(() -> new ResourceNotFoundException("Question not found with id: " + answerSubmission.getQuestionId()));

            boolean indicatesNeed = false;
            // If this question is marked as an assistance trigger and the answer doesn't match the safe expectation
            if (question.isAssistanceTrigger() && !question.getExpectedSafeAnswer().equalsIgnoreCase(answerSubmission.getAnswer())) {
                indicatesNeed = true;
                overallNeedsAssistance = true;
            }

            SurveyAnswer answer = new SurveyAnswer(
                    question,
                    question.getQuestionText(),
                    answerSubmission.getAnswer().toUpperCase(),
                    indicatesNeed
            );
            surveyResponse.addAnswer(answer);
        }

        surveyResponse.setNeedsAssistance(overallNeedsAssistance);
        responseRepository.save(surveyResponse);
    }

    private SurveyQuestionDto mapQuestionToDto(SurveyQuestion q) {
        return new SurveyQuestionDto(
                q.getId(),
                q.getIncidentType(),
                q.getQuestionText(),
                q.getQuestionOrder(),
                q.isAssistanceTrigger(),
                q.getExpectedSafeAnswer()
        );
    }
}
