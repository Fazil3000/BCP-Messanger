package com.bcp.service.kafka;

import com.bcp.service.dto.CampaignCreatedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaProducerService {

    private static final Logger log = LoggerFactory.getLogger(KafkaProducerService.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final String topicName;

    public KafkaProducerService(
            KafkaTemplate<String, Object> kafkaTemplate,
            @Value("${app.kafka.topic.campaign-created:bcp.campaign.created}") String topicName) {
        this.kafkaTemplate = kafkaTemplate;
        this.topicName = topicName;
    }

    public void publishCampaignCreatedEvent(CampaignCreatedEvent event) {
        log.info("Publishing CampaignCreatedEvent to Kafka topic [{}]: Campaign ID={}, Type={}",
                topicName, event.getCampaignId(), event.getIncidentType());

        kafkaTemplate.send(topicName, String.valueOf(event.getCampaignId()), event)
                .whenComplete((result, ex) -> {
                    if (ex == null) {
                        log.info("Successfully delivered CampaignCreatedEvent to topic [{}] partition [{}] offset [{}]",
                                topicName,
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset());
                    } else {
                        log.error("Failed to deliver CampaignCreatedEvent for campaign ID {}: {}",
                                event.getCampaignId(), ex.getMessage());
                    }
                });
    }
}
