package com.bcp.service.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "survey_answers")
public class SurveyAnswer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "survey_response_id", nullable = false)
    private SurveyResponse surveyResponse;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id", nullable = false)
    private SurveyQuestion question;

    @Column(name = "question_text", nullable = false, length = 255)
    private String questionText;

    @Column(name = "answer", nullable = false, length = 10)
    private String answer; // 'YES' or 'NO'

    @Column(name = "indicates_need", nullable = false)
    private boolean indicatesNeed = false;

    public SurveyAnswer() {
    }

    public SurveyAnswer(SurveyQuestion question, String questionText, String answer, boolean indicatesNeed) {
        this.question = question;
        this.questionText = questionText;
        this.answer = answer;
        this.indicatesNeed = indicatesNeed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public SurveyResponse getSurveyResponse() {
        return surveyResponse;
    }

    public void setSurveyResponse(SurveyResponse surveyResponse) {
        this.surveyResponse = surveyResponse;
    }

    public SurveyQuestion getQuestion() {
        return question;
    }

    public void setQuestion(SurveyQuestion question) {
        this.question = question;
    }

    public String getQuestionText() {
        return questionText;
    }

    public void setQuestionText(String questionText) {
        this.questionText = questionText;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public boolean isIndicatesNeed() {
        return indicatesNeed;
    }

    public void setIndicatesNeed(boolean indicatesNeed) {
        this.indicatesNeed = indicatesNeed;
    }
}
