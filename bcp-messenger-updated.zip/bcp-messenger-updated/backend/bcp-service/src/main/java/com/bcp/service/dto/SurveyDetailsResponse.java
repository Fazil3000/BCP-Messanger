package com.bcp.service.dto;

import com.bcp.service.entity.CampaignStatus;
import com.bcp.service.entity.IncidentType;
import java.util.List;

public class SurveyDetailsResponse {

    private String surveyToken;
    private Long campaignId;
    private String title;
    private String message;
    private IncidentType incidentType;
    private CampaignStatus status;
    private List<SurveyQuestionDto> questions;

    public SurveyDetailsResponse() {
    }

    public SurveyDetailsResponse(String surveyToken, Long campaignId, String title, String message, IncidentType incidentType, CampaignStatus status, List<SurveyQuestionDto> questions) {
        this.surveyToken = surveyToken;
        this.campaignId = campaignId;
        this.title = title;
        this.message = message;
        this.incidentType = incidentType;
        this.status = status;
        this.questions = questions;
    }

    public String getSurveyToken() {
        return surveyToken;
    }

    public void setSurveyToken(String surveyToken) {
        this.surveyToken = surveyToken;
    }

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }

    public CampaignStatus getStatus() {
        return status;
    }

    public void setStatus(CampaignStatus status) {
        this.status = status;
    }

    public List<SurveyQuestionDto> getQuestions() {
        return questions;
    }

    public void setQuestions(List<SurveyQuestionDto> questions) {
        this.questions = questions;
    }
}
