package com.bcp.service.controller;

import com.bcp.service.dto.SurveyDetailsResponse;
import com.bcp.service.dto.SurveyQuestionDto;
import com.bcp.service.dto.SurveySubmissionRequest;
import com.bcp.service.entity.IncidentType;
import com.bcp.service.service.SurveyService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bcp")
public class SurveyController {

    private final SurveyService surveyService;

    public SurveyController(SurveyService surveyService) {
        this.surveyService = surveyService;
    }

    @GetMapping("/questions/{incidentType}")
    public ResponseEntity<List<SurveyQuestionDto>> getQuestionsByIncidentType(@PathVariable IncidentType incidentType) {
        List<SurveyQuestionDto> questions = surveyService.getQuestionsByIncidentType(incidentType);
        return ResponseEntity.ok(questions);
    }

    @GetMapping("/surveys/{surveyToken}")
    public ResponseEntity<SurveyDetailsResponse> getSurveyDetails(@PathVariable String surveyToken) {
        SurveyDetailsResponse surveyDetails = surveyService.getSurveyDetailsByToken(surveyToken);
        return ResponseEntity.ok(surveyDetails);
    }

    @PostMapping("/surveys/{surveyToken}/submit")
    public ResponseEntity<Map<String, Object>> submitSurvey(
            @PathVariable String surveyToken,
            @Valid @RequestBody SurveySubmissionRequest request) {
        surveyService.submitSurvey(surveyToken, request);
        Map<String, Object> response = new HashMap<>();
        response.put("status", "SUCCESS");
        response.put("message", "Thank you. Your safety confirmation and assistance responses have been recorded.");
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
