package com.bcp.service.repository;

import com.bcp.service.entity.SurveyAnswer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SurveyAnswerRepository extends JpaRepository<SurveyAnswer, Long> {

    List<SurveyAnswer> findBySurveyResponseId(Long surveyResponseId);

    long countByQuestionIdAndAnswer(Long questionId, String answer);
}
