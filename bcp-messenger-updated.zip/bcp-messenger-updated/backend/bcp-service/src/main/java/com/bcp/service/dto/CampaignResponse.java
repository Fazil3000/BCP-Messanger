package com.bcp.service.dto;

import com.bcp.service.entity.CampaignStatus;
import com.bcp.service.entity.IncidentType;
import java.time.LocalDateTime;

public class CampaignResponse {

    private Long id;
    private String title;
    private String message;
    private IncidentType incidentType;
    private CampaignStatus status;
    private String surveyToken;
    private String surveyUrl;
    private String createdBy;
    private String approvedBy;
    private LocalDateTime createdAt;
    private LocalDateTime approvedAt;
    private LocalDateTime sentAt;
    private LocalDateTime closedAt;

    public CampaignResponse() {
    }

    public CampaignResponse(Long id, String title, String message, IncidentType incidentType, CampaignStatus status,
                            String surveyToken, String surveyUrl, String createdBy, String approvedBy,
                            LocalDateTime createdAt, LocalDateTime approvedAt, LocalDateTime sentAt, LocalDateTime closedAt) {
        this.id = id;
        this.title = title;
        this.message = message;
        this.incidentType = incidentType;
        this.status = status;
        this.surveyToken = surveyToken;
        this.surveyUrl = surveyUrl;
        this.createdBy = createdBy;
        this.approvedBy = approvedBy;
        this.createdAt = createdAt;
        this.approvedAt = approvedAt;
        this.sentAt = sentAt;
        this.closedAt = closedAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public void setIncidentType(IncidentType incidentType) {
        this.incidentType = incidentType;
    }

    public CampaignStatus getStatus() {
        return status;
    }

    public void setStatus(CampaignStatus status) {
        this.status = status;
    }

    public String getSurveyToken() {
        return surveyToken;
    }

    public void setSurveyToken(String surveyToken) {
        this.surveyToken = surveyToken;
    }

    public String getSurveyUrl() {
        return surveyUrl;
    }

    public void setSurveyUrl(String surveyUrl) {
        this.surveyUrl = surveyUrl;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getApprovedAt() {
        return approvedAt;
    }

    public void setApprovedAt(LocalDateTime approvedAt) {
        this.approvedAt = approvedAt;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public LocalDateTime getClosedAt() {
        return closedAt;
    }

    public void setClosedAt(LocalDateTime closedAt) {
        this.closedAt = closedAt;
    }
}
