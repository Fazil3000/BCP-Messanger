package com.bcp.service.service;

import com.bcp.service.dto.DashboardSummaryResponse;
import com.bcp.service.entity.CampaignStatus;
import com.bcp.service.repository.CampaignRepository;
import com.bcp.service.repository.SurveyResponseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {

    private final CampaignRepository campaignRepository;
    private final SurveyResponseRepository surveyResponseRepository;

    public DashboardServiceImpl(CampaignRepository campaignRepository, SurveyResponseRepository surveyResponseRepository) {
        this.campaignRepository = campaignRepository;
        this.surveyResponseRepository = surveyResponseRepository;
    }

    @Override
    public DashboardSummaryResponse getDashboardSummary() {
        long totalCampaigns = campaignRepository.count();
        long activeCampaigns = campaignRepository.countByStatus(CampaignStatus.SENT);
        long totalResponses = surveyResponseRepository.count();
        long assistanceRequiredCount = surveyResponseRepository.countByNeedsAssistanceTrue();

        return new DashboardSummaryResponse(
                totalCampaigns,
                activeCampaigns,
                totalResponses,
                assistanceRequiredCount
        );
    }
}
