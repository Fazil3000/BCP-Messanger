package com.bcp.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class BcpServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BcpServiceApplication.class, args);
    }
}
