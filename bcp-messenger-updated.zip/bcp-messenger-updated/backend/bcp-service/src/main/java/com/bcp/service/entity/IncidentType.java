package com.bcp.service.entity;

public enum IncidentType {
    FLOOD,
    INTERNET_OUTAGE,
    POWER_OUTAGE,
    CYCLONE,
    FIRE_EMERGENCY,
    OTHER
}
