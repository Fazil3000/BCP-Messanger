package com.bcp.service.repository;

import com.bcp.service.entity.SurveyResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SurveyResponseRepository extends JpaRepository<SurveyResponse, Long> {

    List<SurveyResponse> findByCampaignId(Long campaignId);

    Optional<SurveyResponse> findByCampaignIdAndEmployeeEmail(Long campaignId, String employeeEmail);

    long countByCampaignId(Long campaignId);

    long countByCampaignIdAndNeedsAssistanceTrue(Long campaignId);

    long countByNeedsAssistanceTrue();
}
