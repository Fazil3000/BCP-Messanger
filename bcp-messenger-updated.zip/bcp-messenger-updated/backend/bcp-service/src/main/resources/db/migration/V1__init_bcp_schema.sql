-- V1__init_bcp_schema.sql
-- BCP Database Schema and Pre-stored Survey Questions

-- 1. Campaigns Table
CREATE TABLE IF NOT EXISTS campaigns (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    incident_type VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'PENDING_APPROVAL',
    survey_token VARCHAR(100) NOT NULL UNIQUE,
    created_by VARCHAR(100) NOT NULL,
    approved_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL,
    sent_at TIMESTAMP NULL,
    closed_at TIMESTAMP NULL
);

-- 2. Pre-stored Survey Questions Table
CREATE TABLE IF NOT EXISTS survey_questions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    incident_type VARCHAR(50) NOT NULL,
    question_text VARCHAR(255) NOT NULL,
    question_order INT NOT NULL,
    is_assistance_trigger BOOLEAN NOT NULL DEFAULT FALSE,
    expected_safe_answer VARCHAR(10) NOT NULL DEFAULT 'YES',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Survey Responses (Header) Table
CREATE TABLE IF NOT EXISTS survey_responses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    campaign_id BIGINT NOT NULL,
    employee_email VARCHAR(100) NOT NULL,
    employee_name VARCHAR(100) NOT NULL,
    employee_id VARCHAR(50),
    needs_assistance BOOLEAN NOT NULL DEFAULT FALSE,
    comments TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_response_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id) ON DELETE CASCADE
);

-- 4. Survey Answers (Item) Table
CREATE TABLE IF NOT EXISTS survey_answers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    survey_response_id BIGINT NOT NULL,
    question_id BIGINT NOT NULL,
    question_text VARCHAR(255) NOT NULL,
    answer VARCHAR(10) NOT NULL, -- 'YES' or 'NO'
    indicates_need BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_answer_response FOREIGN KEY (survey_response_id) REFERENCES survey_responses(id) ON DELETE CASCADE,
    CONSTRAINT fk_answer_question FOREIGN KEY (question_id) REFERENCES survey_questions(id)
);

-- ----------------------------------------------------------------------
-- Seed Pre-stored Survey Questions by Incident Type
-- ----------------------------------------------------------------------

-- FLOOD
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('FLOOD', 'Are you safe?', 1, TRUE, 'YES'),
('FLOOD', 'Do you need any assistance?', 2, TRUE, 'NO'),
('FLOOD', 'Are you able to work from home?', 3, FALSE, 'YES'),
('FLOOD', 'Do you need temporary accommodation?', 4, TRUE, 'NO'),
('FLOOD', 'Do you need transportation assistance?', 5, TRUE, 'NO');

-- INTERNET_OUTAGE
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('INTERNET_OUTAGE', 'Is your internet connection currently working?', 1, FALSE, 'YES'),
('INTERNET_OUTAGE', 'Are you able to work from another location?', 2, FALSE, 'YES'),
('INTERNET_OUTAGE', 'Do you need connectivity assistance?', 3, TRUE, 'NO');

-- POWER_OUTAGE
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('POWER_OUTAGE', 'Do you currently have electricity?', 1, FALSE, 'YES'),
('POWER_OUTAGE', 'Are you able to work from an alternate location?', 2, FALSE, 'YES');

-- CYCLONE
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('CYCLONE', 'Are you and your family safe?', 1, TRUE, 'YES'),
('CYCLONE', 'Do you need emergency assistance?', 2, TRUE, 'NO'),
('CYCLONE', 'Are you able to work from home?', 3, FALSE, 'YES');

-- FIRE_EMERGENCY
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('FIRE_EMERGENCY', 'Are you safe and evacuated?', 1, TRUE, 'YES'),
('FIRE_EMERGENCY', 'Do you need medical or emergency assistance?', 2, TRUE, 'NO'),
('FIRE_EMERGENCY', 'Do you require emergency shelter?', 3, TRUE, 'NO');

-- OTHER
INSERT INTO survey_questions (incident_type, question_text, question_order, is_assistance_trigger, expected_safe_answer) VALUES
('OTHER', 'Are you currently safe?', 1, TRUE, 'YES'),
('OTHER', 'Do you require any support or assistance from the company?', 2, TRUE, 'NO'),
('OTHER', 'Are you able to perform your work duties?', 3, FALSE, 'YES');
