package com.bcp.user.entity;

public enum Role {
    ADMIN,
    APPROVER,
    EMPLOYEE
}
