package com.bcp.user.service;

import com.bcp.user.dto.UserResponse;
import com.bcp.user.entity.Role;

import java.util.List;

public interface UserService {

    UserResponse getUserById(Long id);

    UserResponse getUserByEmail(String email);

    UserResponse getUserByEmployeeId(String employeeId);

    List<UserResponse> getAllUsers();

    List<UserResponse> getUsersByRole(Role role);
}
