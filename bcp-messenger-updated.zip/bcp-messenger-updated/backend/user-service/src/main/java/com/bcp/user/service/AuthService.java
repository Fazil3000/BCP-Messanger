package com.bcp.user.service;

import com.bcp.user.dto.AuthRequest;
import com.bcp.user.dto.AuthResponse;
import com.bcp.user.dto.RegisterRequest;
import com.bcp.user.dto.UserResponse;

public interface AuthService {

    AuthResponse login(AuthRequest request);

    UserResponse register(RegisterRequest request);
}
