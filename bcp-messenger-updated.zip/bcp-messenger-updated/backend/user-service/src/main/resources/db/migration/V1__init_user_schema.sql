-- V1__init_user_schema.sql

-- Create users table
CREATE TABLE IF NOT EXISTS users (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     employee_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    department VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    role VARCHAR(20) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );

-- Seed initial test accounts
--
-- Admin password:    Admin@123
-- Approver password: Approver@123
-- Employee password: Employee@123

INSERT INTO users
(employee_id, full_name, email, password, department, phone_number, role, active)
VALUES
    (
        'EMP001',
        'System Administrator',
        'admin@company.com',
        '$2a$10$./v0G.oDYZGtdETgFZ2P3usQzU/7eja.439oPgiCdMFkW/BLF3Km6',
        'IT & BCP Ops',
        '+1-555-0101',
        'ADMIN',
        TRUE
    ),
    (
        'EMP002',
        'Incident Approver',
        'approver@company.com',
        '$2a$10$jXTZeicbUKrIiZvjOo9YGe/urPHX9WK8z.M67lZvVJOjo3ziWxiz.',
        'Executive Response',
        '+1-555-0102',
        'APPROVER',
        TRUE
    ),
    (
        'EMP003',
        'John Doe (Dev)',
        'employee1@company.com',
        '$2a$10$jKvSQaApF50us35s735kl.sdMV8O1Ao8YDI0wX07y4xtfMfoW1dxa',
        'Engineering',
        '+1-555-0103',
        'EMPLOYEE',
        TRUE
    ),
    (
        'EMP004',
        'Jane Smith (QA)',
        'employee2@company.com',
        '$2a$10$jKvSQaApF50us35s735kl.sdMV8O1Ao8YDI0wX07y4xtfMfoW1dxa',
        'Quality Assurance',
        '+1-555-0104',
        'EMPLOYEE',
        TRUE
    ),
    (
        'EMP005',
        'Robert Johnson (HR)',
        'employee3@company.com',
        '$2a$10$jKvSQaApF50us35s735kl.sdMV8O1Ao8YDI0wX07y4xtfMfoW1dxa',
        'Human Resources',
        '+1-555-0105',
        'EMPLOYEE',
        TRUE
    )

    ON DUPLICATE KEY UPDATE id = id;