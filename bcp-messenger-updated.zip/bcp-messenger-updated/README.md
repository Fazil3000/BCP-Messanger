# 🛡️ BCP Messenger (Business Continuity Plan Messenger)

> **Enterprise-Grade Microservices Platform for Crisis Management, Emergency Employee Safety Surveys, and Instant Incident Broadcasts.**

---

## 📑 Table of Contents
1. [Project Overview](#1-project-overview)
2. [Architecture Diagram](#2-architecture-diagram)
3. [Why Microservices Architecture?](#3-why-microservices-architecture)
4. [Services Breakdown & Responsibilities](#4-services-breakdown--responsibilities)
5. [Why Spring Cloud Gateway?](#5-why-spring-cloud-gateway)
6. [Why Eureka Service Discovery?](#6-why-eureka-service-discovery)
7. [Why Spring Cloud Config Server?](#7-why-spring-cloud-config-server)
8. [Why Apache Kafka?](#8-why-apache-kafka)
9. [Database Design: MySQL & Database-per-Service](#9-database-design-mysql--database-per-service)
10. [Inter-Service Communication Mechanisms](#10-inter-service-communication-mechanisms)
11. [Complete End-to-End Request Flow](#11-complete-end-to-end-request-flow)
12. [Prerequisites & System Requirements](#12-prerequisites--system-requirements)
13. [Step 1: MySQL Database Setup](#13-step-1-mysql-database-setup)
14. [Step 2: Apache Kafka Setup (KRaft Mode - No Docker Needed)](#14-step-2-apache-kafka-setup-kraft-mode---no-docker-needed)
15. [Step 3: Running Microservices (Step-by-Step Order)](#15-step-3-running-microservices-step-by-step-order)
16. [Step 4: Running React Frontend](#16-step-4-running-react-frontend)
17. [Sample Test Users & Pre-Seeded Data](#17-sample-test-users--pre-seeded-data)
18. [Pre-stored Incident Survey Questions](#18-pre-stored-incident-survey-questions)
19. [Postman API Examples & Workflow](#19-postman-api-examples--workflow)
20. [Email Configuration & Offline Mode](#20-email-configuration--offline-mode)
21. [Troubleshooting & FAQ](#21-troubleshooting--faq)
22. [🎓 Mentor Review Questions & In-Depth Technical Answers](#22--mentor-review-questions--in-depth-technical-answers)

---

## 1. Project Overview

During natural disasters (floods, cyclones), infrastructure emergencies (power grid failures, corporate network outages), or building hazards (fire alarms), organizations must instantly notify personnel, confirm their safety, determine who needs medical/transportation/shelter support, and track organizational operational capability in real-time.

**BCP Messenger** addresses this mission-critical requirement with a modern **Event-Driven Microservices Architecture** built using **Java 17**, **Spring Boot 3.4.2**, **Spring Cloud 2024.0.0**, **Apache Kafka**, **MySQL 8**, **Flyway**, and a reactive **React (Vite)** interface.

---

## 2. Architecture Diagram

```
                                  +------------------------------------+
                                  |         React 18 Frontend          |
                                  |       http://localhost:5173        |
                                  +-----------------+------------------+
                                                    |
                                                    | (REST / JSON + JWT)
                                                    v
                                  +------------------------------------+
                                  |     Spring Cloud API Gateway       |
                                  |       http://localhost:8080        |
                                  |     (Reactive WebFlux Router)      |
                                  +-----------------+------------------+
                                                    |
         +------------------------------------------+------------------------------------------+
         |                                          |                                          |
         v                                          v                                          v
+------------------+                       +------------------+                       +------------------+
|   User Service   |                       |   BCP Service    |                       | Notification Svc |
|  Port: 8081      |                       |  Port: 8082      |                       |  Port: 8083      |
|  - JWT Auth      |                       |  - Campaigns     |                       |  - Email Sender  |
|  - BCrypt Hash   |                       |  - Pre-stored Qs |                       |  - Logs/History  |
|  - Employee Dir  |                       |  - Survey Engine |                       |  - Simulated Dev |
+--------+---------+                       |  - Analytics     |                       +--------+---------+
         |                                 +--------+---------+                                |
         v                                          |                                          v
+------------------+                                v (Publishes Event)               +------------------+
| MySQL:           |                      +--------------------+                      | MySQL:           |
| bcp_user_db      |                      |    Apache Kafka    |                      | bcp_notification |
+------------------+                      |   Topic:           |                      +------------------+
                                          |   bcp.campaign.    |                               ^
                                          |   created          |                               |
                                          +---------+----------+                               |
                                                    |                                          |
                                                    +-----(Consumes CampaignCreatedEvent)------+
                                                    |
                                                    v
                                           +------------------+
                                           | MySQL:           |
                                           | bcp_db           |
                                           +------------------+

Supporting Infrastructure:
-------------------------
1. Eureka Service Discovery  (:8761) -> Central dynamic microservice registry
2. Spring Cloud Config Server (:8888) -> Externalized native configuration
```

---

## 3. Why Microservices Architecture?

A traditional monolithic application bundles authentication, incident coordination, and email/SMS broadcast systems into a single process. In an emergency crisis:

1. **Independent Elastic Scaling**: When an emergency occurs, the Notification Service experiences a sudden spike in workload as it sends thousands of emails, while the User Service experiences minimal traffic. Microservices allow scaling the Notification Service workers independently without allocating resources to unaffected modules.
2. **Fault Isolation (Resilience)**: If the SMTP mail server or external network lags and exhausts threads, only the Notification Service is impacted. Admins can still log in, review surveys, and track responses on the BCP Service without outage.
3. **Decoupled Release Cycles**: Crisis safety logic, pre-stored question banks, and employee HR directories can be evolved, refactored, and deployed by separate engineering teams without coordinated server reboots.

---

## 4. Services Breakdown & Responsibilities

| Service Name | Port | Database | Primary Technologies | Core Responsibilities |
| :--- | :--- | :--- | :--- | :--- |
| **`eureka-server`** | `8761` | None | Spring Cloud Netflix Eureka Server | Service registry for discovery and dynamic load-balanced routing (`lb://SERVICE-NAME`). |
| **`config-server`** | `8888` | None | Spring Cloud Config Server | Native file-based externalized configuration management across environments. |
| **`api-gateway`** | `8080` | None | Spring Cloud Gateway (WebFlux), Eureka Client | Single client entry point, JWT forwarding, route predicate mapping, and CORS management. |
| **`user-service`** | `8081` | `bcp_user_db` | Spring Web, Spring Security, JWT (JJWT 0.12), JPA, Flyway | Employee management, authentication, BCrypt password hashing, and role checks (`ADMIN`, `APPROVER`, `EMPLOYEE`). |
| **`bcp-service`** | `8082` | `bcp_db` | Spring Web, JPA, Spring Kafka Producer, Flyway | Campaign lifecycle (`PENDING_APPROVAL` → `APPROVED` → `SENT`), pre-stored question banks in MySQL, survey submissions, and safety statistics. |
| **`notification-service`**| `8083` | `bcp_notification_db` | Spring Web, Spring Kafka Consumer, JavaMailSender, JPA, Flyway | Asynchronously consumes campaign broadcast events from Kafka, formats emergency alert emails with survey URLs, and maintains delivery logs. |
| **`bcp-frontend`** | `5173` | Browser (LocalStorage) | React 18, Vite, React Router 6, Axios | Responsive portal for incident broadcast, live MySQL question previews, Approver triggers, employee surveys, and analytics. |

---

## 5. Why Spring Cloud Gateway?

- **Single Entry Point**: The React frontend interacts solely with `http://localhost:8080`. Frontend code never hard-codes individual microservice ports (`8081`, `8082`, `8083`).
- **Reactive Non-Blocking Core**: Built on Netty and Project Reactor (`WebFlux`), handling thousands of concurrent requests efficiently without thread-per-request blocking.
- **Dynamic Load Balancing**: Resolves backend routes using `lb://USER-SERVICE`, `lb://BCP-SERVICE`, and `lb://NOTIFICATION-SERVICE` via Eureka.
- **Centralized Cross-Cutting Concerns**: Configured with global CORS rules, centralized rate limiting hooks, and unified header enrichment.

---

## 6. Why Eureka Service Discovery?

In dynamic microservices environments (cloud, containers, autoscaling groups), IP addresses and port numbers fluctuate:
- With **Netflix Eureka**, microservices announce their health and network location upon startup (`eureka.client.serviceUrl.defaultZone`).
- API Gateway and peer services query Eureka for the live registry rather than relying on brittle, hardcoded IP configurations.
- If a service instance fails health heartbeats, Eureka evicts it from the routing table automatically.

---

## 7. Why Spring Cloud Config Server?

- **Externalized Configuration**: Business properties (Kafka topic names, JWT secret keys, SMTP credentials) are stored outside compiled JAR artifacts.
- **Environment Parity**: Configurations can be swapped across `local`, `dev`, `stage`, and `prod` without modifying a single line of Java source code.
- **Native Profile**: This project uses the `native` profile (`classpath:/config`) for lightweight local development without requiring external Git credentials.

---

## 8. Why Apache Kafka?

When an Approver triggers an emergency alert, thousands of emails need to be dispatched.
- **Asynchronous Decoupling**: If the BCP Service sent emails synchronously via REST, the HTTP request would block for 30–60 seconds, leading to browser timeouts and transaction deadlocks.
- **At-Least-Once Delivery**: Kafka persists events on disk across topic partitions (`bcp.campaign.created`). If the Notification Service is temporarily offline or restarted, it resumes message consumption exactly from its committed offset once restored.
- **Scalable Consumer Groups**: Additional instances of Notification Service can join the consumer group (`bcp-notification-group`) to parallelize email dispatches effortlessly.

---

## 9. Database Design: MySQL & Database-per-Service

Every microservice maintains strict schema isolation to enforce domain boundaries:

```
+--------------------------+  +--------------------------+  +--------------------------+
|       bcp_user_db        |  |          bcp_db          |  |   bcp_notification_db    |
+--------------------------+  +--------------------------+  +--------------------------+
| - users                  |  | - campaigns              |  | - notification_logs      |
|   (id, employee_id,      |  | - survey_questions       |  |   (id, campaign_id,      |
|    full_name, email,     |  | - survey_responses       |  |    recipient_email,      |
|    password, department, |  | - survey_answers         |  |    incident_type, title, |
|    role, active)         |  +--------------------------+  |    survey_url, status,   |
+--------------------------+                                |    error_message)        |
                                                            +--------------------------+
```

### Why Flyway with `ddl-auto=validate`?
1. **Predictability**: `hibernate.ddl-auto=update` can corrupt production schemas by dropping constraints or altering columns inconsistently.
2. **Version Control**: Every database change is scripted into versioned SQL files (`V1__init_*.sql`), making migrations reproducible across developer laptops and CI/CD pipelines.

---

## 10. Inter-Service Communication Mechanisms

1. **Synchronous REST (via API Gateway)**:
   - React UI $\rightarrow$ API Gateway $\rightarrow$ `user-service`: User authentication & directory queries.
   - React UI $\rightarrow$ API Gateway $\rightarrow$ `bcp-service`: Fetching pre-stored questions, submitting surveys, and viewing analytics.
2. **Asynchronous Messaging (via Apache Kafka)**:
   - `bcp-service` (Producer) $\xrightarrow{\text{Kafka Event}}$ `bcp.campaign.created` $\xrightarrow{\text{Kafka Consumer}}$ `notification-service`.

---

## 11. Complete End-to-End Request Flow

```
[ 1. Admin/User Login ]
React Form -> POST /api/auth/login -> Gateway :8080 -> user-service :8081 (Checks BCrypt password)
<- Returns JWT Token (contains email, role, employeeId) -> React stores token in localStorage

[ 2. Create BCP Alert ]
Admin selects incident (e.g. "FLOOD") -> React calls GET /api/bcp/questions/FLOOD
<- bcp-service :8082 returns pre-stored questions from MySQL
Admin enters title & message -> POST /api/bcp/campaigns (Status: PENDING_APPROVAL)

[ 3. Approver Approval & Kafka Broadcast ]
Approver clicks "Approve & Send" -> PUT /api/bcp/campaigns/{id}/approve
bcp-service updates status to SENT -> Publishes CampaignCreatedEvent to Kafka topic 'bcp.campaign.created'

[ 4. Asynchronous Notification Dispatch ]
notification-service :8083 consumes event from Kafka
Generates email body with survey link: http://localhost:5173/survey/{surveyToken}
Dispatches email (or logs formatted emergency email to console in offline mode) -> Records log in bcp_notification_db

[ 5. Employee Survey Submission ]
Employee clicks email link -> React opens SurveyPage -> GET /api/bcp/surveys/{surveyToken}
Employee answers YES/NO questions -> POST /api/bcp/surveys/{surveyToken}/submit
bcp-service evaluates answers: if any assistance question is flagged, marks needsAssistance = TRUE
Saves response and individual answers in MySQL

[ 6. Real-time Response Analytics ]
Admin/Approver opens Analytics Dashboard -> GET /api/bcp/campaigns/{id}/analytics
Displays safety percentage gauge, YES vs NO bar charts per question, and urgent assistance employee alerts!
```

---

## 12. Prerequisites & System Requirements

Ensure you have the following installed on your machine (Windows supported natively):

1. **Java Development Kit (JDK)**: Java 17 LTS (`java -version`)
2. **Node.js**: Node v18+ or v24+ (`node -v`)
3. **MySQL Server 8.x**: Running on port `3306` with credentials `root` / `root` (or configured via environment variable)
4. **Apache Kafka 3.x**: Binary download for local KRaft standalone mode
5. **Apache Maven 3.8+** (or IDE built-in Maven in IntelliJ IDEA / VS Code)

---

## 13. Step 1: MySQL Database Setup

Log into MySQL (Workbench or Command Line) and execute the provided setup script:

```bash
mysql -u root -p < scripts/setup-databases.sql
```

Or execute directly in MySQL CLI:
```sql
CREATE DATABASE IF NOT EXISTS bcp_user_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS bcp_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS bcp_notification_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

---

## 14. Step 2: Apache Kafka Setup (KRaft Mode - No Docker Needed)

Apache Kafka 3.x includes **KRaft (Kafka Raft Metadata Mode)**, which operates without Zookeeper.

1. **Download Kafka**:
   Download the Scala 2.13 binary package from [kafka.apache.org/downloads](https://kafka.apache.org/downloads) (e.g. `kafka_2.13-3.7.0.tgz`).
2. **Extract to `C:\kafka`** (or your chosen path).
3. **Initialize & Start Kafka in Windows PowerShell or CMD**:

```powershell
# 1. Navigate to Kafka directory
cd C:\kafka

# 2. Generate a cluster UUID
$CLUSTER_ID = .\bin\windows\kafka-storage.bat random-uuid
Write-Host "Cluster ID: $CLUSTER_ID"

# 3. Format the storage directory
.\bin\windows\kafka-storage.bat format -t $CLUSTER_ID -c .\config\kraft\server.properties

# 4. Start the Kafka broker on port 9092
.\bin\windows\kafka-server-start.bat .\config\kraft\server.properties
```

*Alternatively, run the pre-built script:*
```cmd
scripts\start-kafka-kraft.bat
```

---

## 15. Step 3: Running Microservices (Step-by-Step Order)

Open separate terminal windows (or import each project into IntelliJ IDEA) and start the services in the following order:

### 1. Eureka Discovery Server (Port 8761)
```cmd
cd backend\eureka-server
mvn spring-boot:run
```
*Verify: Open `http://localhost:8761` in browser.*

### 2. Spring Cloud Config Server (Port 8888)
```cmd
cd backend\config-server
mvn spring-boot:run
```
*Verify: Open `http://localhost:8888/user-service/default`.*

### 3. User Service (Port 8081)
```cmd
cd backend\user-service
mvn spring-boot:run
```
*Flyway will automatically create `users` table and seed test accounts.*

### 4. BCP Service (Port 8082)
```cmd
cd backend\bcp-service
mvn spring-boot:run
```
*Flyway will automatically seed pre-stored questions for all 6 incident types.*

### 5. Notification Service (Port 8083)
```cmd
cd backend\notification-service
mvn spring-boot:run
```
*Connects to Kafka consumer group `bcp-notification-group`.*

### 6. Spring Cloud API Gateway (Port 8080)
```cmd
cd backend\api-gateway
mvn spring-boot:run
```

> **Automated One-Click Startup Script (Windows):**
> Simply run:
> ```cmd
> scripts\start-all-services.bat
> ```

---

## 16. Step 4: Running React Frontend

Open a terminal in the `frontend` folder:

```bash
cd frontend
npm install
npm run dev
```

Open your browser at: **`http://localhost:5173`**

---

## 17. Sample Test Users & Pre-Seeded Data

All accounts are pre-seeded via Flyway with standard BCrypt password hashing:

| Email | Password | Role | Employee ID | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| `admin@company.com` | `Admin@123` | `ADMIN` | `EMP001` | Full administrative control: create campaigns, review all stats. |
| `approver@company.com`| `Approver@123`| `APPROVER`| `EMP002` | Crisis Commander: review and approve emergency alerts. |
| `employee1@company.com`|`Employee@123`| `EMPLOYEE`| `EMP003` | Employee in Engineering (Sample responder). |
| `employee2@company.com`|`Employee@123`| `EMPLOYEE`| `EMP004` | Employee in QA (Sample responder needing assistance). |
| `employee3@company.com`|`Employee@123`| `EMPLOYEE`| `EMP005` | Employee in HR (Sample responder). |

---

## 18. Pre-stored Incident Survey Questions

Questions are dynamically retrieved from the MySQL database (`bcp_db.survey_questions`):

### 🌊 FLOOD
1. Are you safe? *(Expected: YES)*
2. Do you need any assistance? *(Expected: NO; YES triggers Assistance Flag)*
3. Are you able to work from home? *(Expected: YES)*
4. Do you need temporary accommodation? *(Expected: NO; YES triggers Assistance Flag)*
5. Do you need transportation assistance? *(Expected: NO; YES triggers Assistance Flag)*

### 🌐 INTERNET_OUTAGE
1. Is your internet connection currently working?
2. Are you able to work from another location?
3. Do you need connectivity assistance? *(YES triggers Assistance Flag)*

### ⚡ POWER_OUTAGE
1. Do you currently have electricity?
2. Are you able to work from an alternate location?

### 🌀 CYCLONE
1. Are you and your family safe? *(Expected: YES)*
2. Do you need emergency assistance? *(Expected: NO; YES triggers Assistance Flag)*
3. Are you able to work from home? *(Expected: YES)*

### 🔥 FIRE_EMERGENCY
1. Are you safe and evacuated? *(Expected: YES)*
2. Do you need medical or emergency assistance? *(Expected: NO; YES triggers Assistance Flag)*
3. Do you require emergency shelter? *(Expected: NO; YES triggers Assistance Flag)*

### ⚠️ OTHER
1. Are you currently safe? *(Expected: YES)*
2. Do you require any support or assistance from the company? *(Expected: NO; YES triggers Assistance Flag)*
3. Are you able to perform your work duties? *(Expected: YES)*

---

## 19. Postman API Examples & Workflow

Import `postman/BCP_Messenger_API_Collection.json` into Postman.

### 1. Authenticate (Login)
```http
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "email": "admin@company.com",
  "password": "Admin@123"
}
```

### 2. Fetch Pre-stored Questions Dynamically
```http
GET http://localhost:8080/api/bcp/questions/FLOOD
```

### 3. Create Campaign
```http
POST http://localhost:8080/api/bcp/campaigns
Content-Type: application/json
X-User-Email: admin@company.com

{
  "title": "Heavy Flooding in Chennai",
  "message": "Due to continuous torrential rain, please confirm your safety status.",
  "incidentType": "FLOOD"
}
```

### 4. Approve Campaign (Triggers Kafka Dispatch)
```http
PUT http://localhost:8080/api/bcp/campaigns/1/approve
X-User-Email: approver@company.com
```

### 5. Submit Employee Survey Response
```http
POST http://localhost:8080/api/bcp/surveys/{surveyToken}/submit
Content-Type: application/json

{
  "employeeEmail": "employee1@company.com",
  "employeeName": "John Doe",
  "employeeId": "EMP003",
  "comments": "Safe at home, no assistance needed.",
  "answers": [
    { "questionId": 1, "answer": "YES" },
    { "questionId": 2, "answer": "NO" },
    { "questionId": 3, "answer": "YES" },
    { "questionId": 4, "answer": "NO" },
    { "questionId": 5, "answer": "NO" }
  ]
}
```

### 6. View Live Analytics
```http
GET http://localhost:8080/api/bcp/campaigns/1/analytics
```

---

## 20. Email Configuration & Offline Mode

- By default, `app.email.enabled=false` in `notification-service/src/main/resources/application.yml`.
- When set to `false`, the Notification Service logs formatted emergency emails cleanly to the console and marks records as `SIMULATED` in the MySQL database table `notification_logs`.
- To enable live SMTP delivery (e.g. Gmail):
  1. Set environment variable `APP_EMAIL_ENABLED=true`
  2. Provide `MAIL_USERNAME=your-email@gmail.com` and `MAIL_PASSWORD=your-app-password`

---

## 21. Troubleshooting & FAQ

1. **Port Already in Use Error (`Address already in use: bind`)**:
   Run the port clearing utility:
   ```cmd
   scripts\stop-all-services.bat
   ```
2. **Kafka Connection Refused (`Connection to node -1 could not be established`)**:
   Ensure Kafka broker is running on port `9092` before launching `bcp-service` and `notification-service`.
3. **Database Access Denied**:
   Ensure MySQL service is running on `localhost:3306`. Check username and password in `application.yml` (default `root`/`root`).

---

## 22. 🎓 Mentor Review Questions & In-Depth Technical Answers

Prepare for your technical evaluation with these standard microservices architectural defense points:

---

### Q1: Why did you choose a Microservices Architecture instead of a Monolith?
> **Answer**:
> In a crisis response platform like BCP Messenger, different functional areas experience radically asymmetrical load patterns. During an incident, the notification engine must burst to handle thousands of dispatches across email channels, whereas authentication and campaign configuration traffic remain low. A monolithic architecture would force the entire application to scale together, bottlenecking CPU and thread pools. With microservices:
> 1. We isolate failure domains (an email provider outage never halts safety survey collection).
> 2. We allow independent horizontal autoscaling of notification workers.
> 3. We maintain clean bounded contexts with decoupled domain data models.

---

### Q2: Why is an API Gateway necessary? Why not let React call individual microservices directly?
> **Answer**:
> Without an API Gateway:
> 1. The client would be tightly coupled to internal network topology (hardcoding ports `8081`, `8082`, `8083`).
> 2. CORS configuration would have to be duplicated across every individual backend service.
> 3. Aggregation, dynamic load balancing, and centralized token verification would require repetitive boilerplate across services.
> 
> The **Spring Cloud Gateway** acts as a reverse proxy, translating external REST routes to logical discovery URIs like `lb://BCP-SERVICE` via Eureka.

---

### Q3: Why does Spring Cloud Gateway use WebFlux instead of Spring MVC (`spring-boot-starter-web`)?
> **Answer**:
> Spring Cloud Gateway is built natively on top of Project Reactor and Netty using a reactive, non-blocking I/O model. Traditional Spring MVC allocates one OS thread per incoming request (thread-per-connection). Under high load, a traditional gateway could exhaust its thread pool waiting on slow downstream responses. WebFlux uses an event-loop model that handles tens of thousands of concurrent connections on a minimal thread footprint. Adding `spring-boot-starter-web` introduces Tomcat and blocks the reactive Netty engine, causing fatal startup conflicts.

---

### Q4: Why is Eureka used, and what does `lb://SERVICE-NAME` mean?
> **Answer**:
> **Eureka** is a client-side Service Discovery registry. When microservices boot up, they register their ephemeral network address (IP and port) under a logical `spring.application.name` (e.g. `BCP-SERVICE`).
> The prefix `lb://` instructs Spring Cloud's reactive load balancer to resolve the logical service name against Eureka's live instance registry, distributing traffic across healthy instances with round-robin load balancing.

---

### Q5: Why do we use Apache Kafka for campaign creation instead of sending emails directly inside BCP Service?
> **Answer**:
> 1. **Thread Non-Blocking & Response Latency**: Dispatching emails via SMTP takes 1–3 seconds per recipient. Sending emails to 500 employees synchronously inside the HTTP request would block for 15+ minutes, causing HTTP 504 Gateway Timeouts.
> 2. **Fault Tolerance & Durability**: If the Notification Service or mail server is temporarily down, Kafka retains the message on disk. When the service recovers, it resumes reading from its committed offset with zero data loss.
> 3. **Decoupling**: BCP Service is solely responsible for incident domain logic, while Notification Service owns channel-specific formatting and dispatching.

---

### Q6: Why do we use Synchronous REST for surveys and Asynchronous Kafka for notifications?
> **Answer**:
> - **Synchronous REST** is required when the client immediately needs the result or return payload (e.g. login tokens, survey questions for rendering UI, validation errors on submission).
> - **Asynchronous Kafka** is optimal for fire-and-forget, background, or multi-step pipeline processing (e.g. publishing `CampaignCreatedEvent` where BCP Service does not need to wait for email delivery to complete).

---

### Q7: Why do we use Database-per-Service instead of a shared database?
> **Answer**:
> A shared database is an anti-pattern known as a "Database Monolith" or "Shared-Data Integration":
> 1. If multiple services query and update the same tables, changes to one service's schema risk breaking unrelated services.
> 2. It bypasses domain encapsulation and risks table locking conflicts.
> By giving each service its own database (`bcp_user_db`, `bcp_db`, `bcp_notification_db`), each microservice has complete autonomy over its schema, migration lifecycle, and data persistence technology.

---

### Q8: Why do we use JWT (JSON Web Tokens) for authentication?
> **Answer**:
> In a microservices architecture, server-side HTTP session storage (e.g. in-memory Tomcat sessions) fails because requests are load-balanced across multiple service instances.
> JWT provides a **stateless, cryptographically signed token**. The API Gateway or downstream services verify the HMAC-SHA256 signature locally without querying a central session database on every request, ensuring high throughput.

---

### Q9: Why is BCrypt used for password storage?
> **Answer**:
> Plain hashing algorithms like MD5 or SHA-256 are vulnerable to rainbow table attacks and brute-force GPU cracking. **BCrypt** includes a cryptographic salt and uses an adaptive key derivation function with an adjustable work factor (cost parameter), making brute-force attacks computationally infeasible.

---

### Q10: Why do we use Constructor Injection instead of Field Injection (`@Autowired`)?
> **Answer**:
> 1. **Immutability**: Dependencies can be declared `final`, ensuring thread-safe state after object instantiation.
> 2. **Testability**: Allows unit testing with simple mock injection without requiring Spring context reflection (`ReflectionTestUtils`).
> 3. **Fail-Fast Safety**: Prevents `NullPointerException` at runtime if a required dependency is missing during application startup.

---

### Q11: What is Flyway, and why do we use `ddl-auto=validate`?
> **Answer**:
> Flyway is a database migration tool that tracks schema versions using sequential SQL migration files (`V1__...`, `V2__...`).
> Setting `hibernate.ddl-auto=validate` ensures Hibernate only verifies that entity mappings match the existing database schema without executing arbitrary DDL modifications, preventing accidental column drops or data corruption in production environments.

---

### Q12: What happens if Notification Service is down when a campaign is approved?
> **Answer**:
> The `bcp-service` successfully publishes the `CampaignCreatedEvent` to the Kafka broker topic `bcp.campaign.created`. The event is safely persisted in Kafka's transaction log. As soon as `notification-service` is restarted, its consumer group connects to Kafka, detects uncommitted offsets, and processes all pending notifications immediately.

---

### Q13: What happens if Kafka is down when a campaign is approved?
> **Answer**:
> The `bcp-service` Kafka producer will attempt retries based on its configuration. If Kafka remains unreachable, the transaction fails with an error, preventing the campaign from being marked as `SENT` without event dispatch confirmation. The Approver can safely retry the approval once Kafka is restored.

---

### Q14: What happens if Eureka Server is down?
> **Answer**:
> Eureka clients (API Gateway, BCP Service) maintain a local in-memory cache of the service registry. If Eureka Server goes down, microservices can continue routing to existing known instances for a period of time using their cached routing table until instances change network addresses.

---

### Q15: Why didn't we use a Maven Parent POM or Multi-Module project?
> **Answer**:
> In true enterprise microservices, each service is housed in its own source repository with an independent CI/CD build pipeline and version lifecycle. A multi-module Maven project couples all services to a single build tree, forcing all services to share compiler plugins, dependencies, and deployment schedules, effectively creating a "distributed monolith" build pipeline.

---

## 23. Conclusion & Quality Checklist

- [x] True microservices architecture (6 backend services + React frontend).
- [x] Zero parent/root POM, zero `<modules>`, zero shared libraries.
- [x] Spring Initializr standard layout for all 6 Spring Boot services.
- [x] Spring Boot 3.4.2 & Spring Cloud 2024.0.0 official compatibility.
- [x] Apache Kafka event publisher & consumer on `bcp.campaign.created`.
- [x] Isolated MySQL databases with versioned Flyway migrations.
- [x] Pre-stored database survey questions for all 6 incident types.
- [x] JWT authentication with BCrypt password hashing.
- [x] Clean constructor injection and layered architecture.
- [x] Complete Windows batch startup scripts (No Docker required).
- [x] Exhaustive Postman API collection with sample request flows.
- [x] Complete technical mentor review guide.
